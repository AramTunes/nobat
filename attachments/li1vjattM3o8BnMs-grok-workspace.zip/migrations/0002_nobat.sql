-- نوبتک schema. Times are timestamptz (UTC). Each business stores its own timezone.
-- Cancelled bookings do not occupy capacity (status filter, not a deleted row).
-- No btree_gist: overlap is prevented by locking the staff row inside a transaction.

create table if not exists categories (
  id text primary key,
  name text not null,
  slug text not null unique,
  sort int not null default 0,
  active boolean not null default true
);

create table if not exists profiles (
  user_id text primary key,
  display_name text not null default '',
  phone text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists platform_admins (
  user_id text primary key,
  created_at timestamptz not null default now()
);

create table if not exists businesses (
  id text primary key,
  owner_user_id text not null,
  name text not null,
  slug text not null unique,
  description text not null default '',
  category_id text references categories (id),
  city text not null default '',
  address text not null default '',
  phone text not null default '',
  timezone text not null default 'Asia/Tehran',
  status text not null default 'active' check (status in ('active', 'inactive', 'suspended')),
  status_reason text not null default '',
  cancel_before_minutes int not null default 120 check (cancel_before_minutes >= 0),
  min_lead_minutes int not null default 60 check (min_lead_minutes >= 0),
  max_horizon_days int not null default 30 check (max_horizon_days between 1 and 180),
  slot_step_minutes int not null default 15 check (slot_step_minutes between 5 and 60),
  allow_any_staff boolean not null default true,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists businesses_owner_idx on businesses (owner_user_id);
create index if not exists businesses_status_idx on businesses (status);

create table if not exists memberships (
  business_id text not null references businesses (id) on delete cascade,
  user_id text not null,
  role text not null check (role in ('owner', 'manager', 'staff')),
  primary key (business_id, user_id)
);

create index if not exists memberships_user_idx on memberships (user_id);

create table if not exists branches (
  id text primary key,
  business_id text not null references businesses (id) on delete cascade,
  name text not null,
  address text not null default '',
  active boolean not null default true
);

create index if not exists branches_business_idx on branches (business_id);

create table if not exists services (
  id text primary key,
  business_id text not null references businesses (id) on delete cascade,
  branch_id text references branches (id) on delete set null,
  name text not null,
  description text not null default '',
  duration_minutes int not null check (duration_minutes between 5 and 480),
  buffer_minutes int not null default 0 check (buffer_minutes between 0 and 180),
  price_toman int not null default 0 check (price_toman >= 0),
  active boolean not null default true
);

create index if not exists services_business_idx on services (business_id);

create table if not exists staff (
  id text primary key,
  business_id text not null references businesses (id) on delete cascade,
  branch_id text not null references branches (id) on delete cascade,
  user_id text,
  name text not null,
  title text not null default '',
  active boolean not null default true
);

create index if not exists staff_business_idx on staff (business_id);

create table if not exists staff_services (
  staff_id text not null references staff (id) on delete cascade,
  service_id text not null references services (id) on delete cascade,
  primary key (staff_id, service_id)
);

-- weekday: 0 sunday … 6 saturday, interpreted in the business timezone.
create table if not exists working_hours (
  id text primary key,
  staff_id text not null references staff (id) on delete cascade,
  weekday int not null check (weekday between 0 and 6),
  start_min int not null check (start_min >= 0 and start_min < 1440),
  end_min int not null check (end_min > 0 and end_min <= 1440),
  check (end_min > start_min)
);

create index if not exists working_hours_staff_idx on working_hours (staff_id, weekday);

create table if not exists breaks (
  id text primary key,
  staff_id text not null references staff (id) on delete cascade,
  weekday int not null check (weekday between 0 and 6),
  start_min int not null check (start_min >= 0 and start_min < 1440),
  end_min int not null check (end_min > 0 and end_min <= 1440),
  check (end_min > start_min)
);

create index if not exists breaks_staff_idx on breaks (staff_id, weekday);

create table if not exists holidays (
  id text primary key,
  business_id text not null references businesses (id) on delete cascade,
  staff_id text references staff (id) on delete cascade,
  date_local date not null,
  note text not null default ''
);

create index if not exists holidays_business_date_idx on holidays (business_id, date_local);

create table if not exists customers (
  id text primary key,
  business_id text not null references businesses (id) on delete cascade,
  user_id text,
  name text not null,
  phone text not null default '',
  notes text not null default '',
  created_at timestamptz not null default now()
);

create unique index if not exists customers_user_uq
  on customers (business_id, user_id)
  where user_id is not null;

create index if not exists customers_business_idx on customers (business_id);

create table if not exists bookings (
  id text primary key,
  business_id text not null references businesses (id) on delete cascade,
  branch_id text not null,
  service_id text not null,
  staff_id text not null,
  customer_id text not null references customers (id),
  customer_user_id text,
  created_by_user_id text not null,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  buffer_until timestamptz not null,
  status text not null check (status in ('pending', 'confirmed', 'completed', 'cancelled', 'no_show')),
  source text not null default 'online' check (source in ('online', 'manual')),
  idempotency_key text,
  note text not null default '',
  cancel_reason text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_at > starts_at),
  check (buffer_until >= ends_at)
);

create unique index if not exists bookings_idempotency_uq
  on bookings (business_id, idempotency_key)
  where idempotency_key is not null;

create index if not exists bookings_staff_time_idx on bookings (staff_id, starts_at);
create index if not exists bookings_business_time_idx on bookings (business_id, starts_at);
create index if not exists bookings_customer_user_idx on bookings (customer_user_id, starts_at);

create table if not exists notifications (
  id text primary key,
  user_id text not null,
  business_id text,
  booking_id text,
  kind text not null,
  title text not null,
  body text not null,
  channel text not null default 'in_app',
  status text not null default 'recorded',
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists notifications_user_idx on notifications (user_id, created_at desc);

-- SMS/email are not sent unless a real provider is configured. Default is skipped.
create table if not exists notification_jobs (
  id text primary key,
  channel text not null check (channel in ('sms', 'email')),
  payload text not null,
  status text not null default 'skipped' check (status in ('queued', 'sent', 'failed', 'skipped')),
  attempts int not null default 0,
  last_error text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id text primary key,
  actor_user_id text not null,
  business_id text,
  action text not null,
  entity text not null,
  entity_id text,
  detail text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists audit_logs_created_idx on audit_logs (created_at desc);

-- Payment boundary for later versions. Nothing in MVP writes status = 'active'.
create table if not exists subscriptions (
  id text primary key,
  business_id text not null references businesses (id) on delete cascade,
  plan text not null default 'free',
  status text not null default 'none' check (status in ('none', 'active', 'past_due', 'canceled')),
  created_at timestamptz not null default now()
);

create table if not exists platform_settings (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

insert into categories (id, name, slug, sort) values
  ('cat-beauty', 'زیبایی و آرایش', 'beauty', 1),
  ('cat-health', 'سلامت', 'health', 2),
  ('cat-consult', 'مشاوره', 'consult', 3),
  ('cat-edu', 'آموزش', 'education', 4),
  ('cat-sport', 'ورزش', 'sport', 5),
  ('cat-auto', 'خودرو', 'auto', 6),
  ('cat-pets', 'حیوانات خانگی', 'pets', 7),
  ('cat-other', 'سایر', 'other', 8)
on conflict (id) do nothing;

insert into platform_settings (key, value) values
  ('platform_name', 'نوبتک'),
  ('support_email', '')
on conflict (key) do nothing;
