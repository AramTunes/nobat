alter table profiles add column if not exists username text;
alter table profiles add column if not exists activity_id text;
alter table profiles add column if not exists page_for text;
alter table profiles add column if not exists page_name text;
alter table profiles add column if not exists has_password boolean not null default false;

create unique index if not exists profiles_phone_uq on profiles (phone) where phone <> '';
create unique index if not exists profiles_username_uq on profiles (lower(username)) where username is not null and username <> '';

create table if not exists phone_codes (
  id text primary key,
  phone text not null,
  purpose text not null,
  code_hash text not null,
  expires_at timestamptz not null,
  attempts integer not null default 0,
  consumed_at timestamptz
);

create index if not exists phone_codes_lookup_idx on phone_codes (phone, purpose, expires_at desc);
