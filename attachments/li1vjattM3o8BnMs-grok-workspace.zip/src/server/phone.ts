import { createHash, randomInt, timingSafeEqual } from "node:crypto";
import { getRequest } from "@tanstack/react-start/server";
import { auth } from "@/lib/auth/server";
import { getSql } from "@/lib/db";
import { DomainError, provisionStartPage } from "./domain";

const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";
const CODE_TTL_MS = 10 * 60 * 1000;
const hits = new Map<string, number[]>();

type Purpose = "login" | "reset" | "signup";

type AccountRow = {
  user_id: string;
  email: string;
  has_password: boolean;
};

function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const recent = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (recent.length >= limit) {
    hits.set(key, recent);
    return false;
  }
  recent.push(now);
  hits.set(key, recent);
  return true;
}

function asRecord(input: unknown): Record<string, unknown> {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new DomainError("درخواست نامعتبر است", "VALIDATION");
  }
  return input as Record<string, unknown>;
}

function readString(input: Record<string, unknown>, key: string): string {
  const value = input[key];
  if (typeof value !== "string") throw new DomainError("درخواست نامعتبر است", "VALIDATION");
  return value;
}

export function normalizePhone(raw: string): string {
  const digits = raw
    .replace(/[۰-۹]/g, (ch) => String(FA_DIGITS.indexOf(ch)))
    .replace(/\D/g, "");
  let phone = digits;
  if (phone.startsWith("0098")) phone = `0${phone.slice(4)}`;
  else if (phone.startsWith("98") && phone.length === 12) phone = `0${phone.slice(2)}`;
  else if (phone.startsWith("9") && phone.length === 10) phone = `0${phone}`;
  if (!/^09\d{9}$/.test(phone)) throw new DomainError("شماره موبایل معتبر نیست", "VALIDATION");
  return phone;
}

function normalizeUsername(raw: string): string {
  const username = raw.trim();
  if (!/^[\p{L}\p{N}_]{3,24}$/u.test(username)) {
    throw new DomainError("نام کاربری باید ۳ تا ۲۴ حرف، عدد یا _ باشد", "VALIDATION");
  }
  return username;
}

function phoneEmail(phone: string): string {
  return `${phone}@phone.nobatak.ir`;
}

function hashCode(phone: string, purpose: Purpose, code: string): string {
  return createHash("sha256").update(`${purpose}:${phone}:${code}`).digest("hex");
}

function hashesMatch(a: string, b: string): boolean {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

function requestHeaders(): Headers {
  return getRequest()?.headers ?? new Headers();
}

async function accountByPhone(phone: string): Promise<AccountRow | null> {
  const sql = await getSql();
  const rows = await sql.query<AccountRow>(
    `select p.user_id, u.email, p.has_password
     from profiles p
     join "user" u on u.id = p.user_id
     where p.phone = $1`,
    [phone],
  );
  return rows[0] ?? null;
}

function authMessage(err: unknown, fallback: string): never {
  const message = err instanceof Error ? err.message : "";
  if (/already|exist|unique/i.test(message)) {
    throw new DomainError("این شماره قبلاً ثبت شده است", "CONFLICT", 409);
  }
  if (/password/i.test(message)) throw new DomainError("رمز عبور نادرست است", "AUTH");
  console.error("[phone-auth]", err instanceof Error ? err.name : "error");
  throw new DomainError(fallback, "AUTH");
}

async function openSession(userId: string): Promise<string> {
  const ctx = await auth.$context;
  const session = await ctx.internalAdapter.createSession(userId);
  if (!session?.token) throw new DomainError("ورود انجام نشد", "AUTH");
  return session.token;
}

export async function lookupPhone(raw: unknown) {
  const phone = normalizePhone(readString(asRecord(raw), "phone"));
  if (!rateLimit(`lookup:${phone}`, 20, 60_000)) {
    throw new DomainError("چند لحظه بعد دوباره تلاش کنید", "RATE", 429);
  }
  const account = await accountByPhone(phone);
  return { registered: Boolean(account) };
}

export async function sendPhoneCode(raw: unknown) {
  const input = asRecord(raw);
  const phone = normalizePhone(readString(input, "phone"));
  const purpose = readString(input, "purpose");
  if (purpose !== "login" && purpose !== "reset" && purpose !== "signup") {
    throw new DomainError("درخواست نامعتبر است", "VALIDATION");
  }
  if (!rateLimit(`code:${phone}`, 5, CODE_TTL_MS)) {
    throw new DomainError("تعداد درخواست کد زیاد است. کمی بعد دوباره بخواهید", "RATE", 429);
  }
  const account = await accountByPhone(phone);
  if (purpose === "signup") {
    if (account) throw new DomainError("این شماره قبلاً ثبت شده است. از ورود استفاده کنید", "CONFLICT", 409);
  } else if (!account) {
    throw new DomainError("این شماره ثبت نشده است. از شروع رایگان حساب بسازید", "NOT_FOUND", 404);
  }
  const code = randomInt(0, 1_000_000).toString().padStart(6, "0");
  const sql = await getSql();
  await sql.query(
    `update phone_codes set consumed_at = now()
     where phone = $1 and purpose = $2 and consumed_at is null`,
    [phone, purpose],
  );
  await sql.query(
    `insert into phone_codes (id, phone, purpose, code_hash, expires_at)
     values ($1,$2,$3,$4,$5)`,
    [crypto.randomUUID(), phone, purpose, hashCode(phone, purpose, code), new Date(Date.now() + CODE_TTL_MS)],
  );
  return { sent: true, code };
}

async function consumeCode(phone: string, purpose: Purpose, code: string) {
  if (!/^\d{6}$/.test(code)) throw new DomainError("کد تأیید ۶ رقمی را وارد کنید", "VALIDATION");
  const sql = await getSql();
  const rows = await sql.query<{ id: string; code_hash: string; attempts: number; expires_at: string | Date }>(
    `select id, code_hash, attempts, expires_at
     from phone_codes
     where phone = $1 and purpose = $2 and consumed_at is null
     order by expires_at desc
     limit 1`,
    [phone, purpose],
  );
  const row = rows[0];
  if (!row || new Date(row.expires_at).getTime() < Date.now() || row.attempts >= 5) {
    throw new DomainError("کد منقضی یا نادرست است. دوباره درخواست کنید", "CODE");
  }
  if (!hashesMatch(row.code_hash, hashCode(phone, purpose, code))) {
    await sql.query(`update phone_codes set attempts = attempts + 1 where id = $1`, [row.id]);
    throw new DomainError("کد تأیید نادرست است", "CODE");
  }
  await sql.query(`update phone_codes set consumed_at = now() where id = $1`, [row.id]);
}

export async function signInWithPassword(raw: unknown) {
  const input = asRecord(raw);
  const phone = normalizePhone(readString(input, "phone"));
  const password = readString(input, "password");
  if (!rateLimit(`pass:${phone}`, 8, 60_000)) {
    throw new DomainError("تلاش زیاد بود. کمی بعد دوباره وارد شوید", "RATE", 429);
  }
  const account = await accountByPhone(phone);
  if (!account) throw new DomainError("این شماره ثبت نشده است", "NOT_FOUND", 404);
  if (!account.has_password) {
    throw new DomainError("هنوز رمزی نگذاشته‌اید. ورود بدون رمز را بزنید", "AUTH");
  }
  try {
    const signed = await auth.api.signInEmail({
      body: { email: account.email, password },
      headers: requestHeaders(),
    });
    if (!signed?.token) throw new DomainError("ورود انجام نشد", "AUTH");
    return { token: signed.token };
  } catch (err) {
    if (err instanceof DomainError) throw err;
    authMessage(err, "رمز عبور نادرست است");
  }
}

export async function signInWithCode(raw: unknown) {
  const input = asRecord(raw);
  const phone = normalizePhone(readString(input, "phone"));
  const code = readString(input, "code").trim();
  const account = await accountByPhone(phone);
  if (!account) throw new DomainError("این شماره ثبت نشده است", "NOT_FOUND", 404);
  await consumeCode(phone, "login", code);
  return { token: await openSession(account.user_id) };
}

export async function resetPasswordWithCode(raw: unknown) {
  const input = asRecord(raw);
  const phone = normalizePhone(readString(input, "phone"));
  const code = readString(input, "code").trim();
  const password = readString(input, "password");
  const confirm = readString(input, "confirm");
  if (password.length < 8) throw new DomainError("رمز باید حداقل ۸ نویسه باشد", "VALIDATION");
  if (password !== confirm) throw new DomainError("تکرار رمز با رمز یکی نیست", "VALIDATION");
  const account = await accountByPhone(phone);
  if (!account) throw new DomainError("این شماره ثبت نشده است", "NOT_FOUND", 404);
  await consumeCode(phone, "reset", code);
  const ctx = await auth.$context;
  const hash = await ctx.password.hash(password);
  await ctx.internalAdapter.updatePassword(account.user_id, hash);
  const sql = await getSql();
  await sql.query(`update profiles set has_password = true where user_id = $1`, [account.user_id]);
  return { token: await openSession(account.user_id) };
}

export async function startAccount(raw: unknown) {
  const input = asRecord(raw);
  const categoryId = readString(input, "categoryId").trim();
  const pageFor = readString(input, "pageFor");
  const pageName = readString(input, "pageName").trim();
  const username = normalizeUsername(readString(input, "username"));
  const phone = normalizePhone(readString(input, "phone"));
  const code = readString(input, "code").trim();
  if (pageFor !== "self" && pageFor !== "business") {
    throw new DomainError("مشخص کنید صفحه برای خودتان است یا کسب‌وکارتان", "VALIDATION");
  }
  if (pageName.length < 2) throw new DomainError("اسم صفحه را بنویسید", "VALIDATION");
  if (!rateLimit(`start:${phone}`, 5, 60_000)) {
    throw new DomainError("چند لحظه بعد دوباره تلاش کنید", "RATE", 429);
  }
  const sql = await getSql();
  const existingPhone = await accountByPhone(phone);
  if (existingPhone) throw new DomainError("این شماره قبلاً ثبت شده است. وارد شوید", "CONFLICT", 409);
  const takenName = await sql.query(
    `select user_id from profiles where lower(username) = lower($1)`,
    [username],
  );
  if (takenName.length) throw new DomainError("این نام کاربری گرفته شده است", "CONFLICT", 409);
  const category = await sql.query(`select id from categories where id = $1 and active = true`, [categoryId]);
  if (!category.length) throw new DomainError("حوزه فعالیت را انتخاب کنید", "VALIDATION");
  await consumeCode(phone, "signup", code);

  let userId = "";
  try {
    const signed = await auth.api.signUpEmail({
      body: {
        email: phoneEmail(phone),
        password: `${crypto.randomUUID()}Aa9!`,
        name: pageName,
      },
      headers: requestHeaders(),
    });
    if (!signed?.user?.id || !signed.token) throw new DomainError("حساب ساخته نشد", "AUTH");
    userId = signed.user.id;
    await provisionStartPage(userId, { pageName, phone, username, categoryId, pageFor });
    return { token: signed.token };
  } catch (err) {
    if (userId) {
      await sql.query(`delete from "user" where id = $1`, [userId]).catch(() => undefined);
    }
    if (err instanceof DomainError) throw err;
    authMessage(err, "حساب ساخته نشد. دوباره تلاش کنید.");
  }
}
