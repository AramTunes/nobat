import { getSql, withTransaction, type Sql } from "@/lib/db";
import { dayAvailability, occupiedMinutesOnDay, type StaffCalendar } from "@/lib/booking/availability.ts";
import { insertBookingIfFree, moveBookingIfFree } from "@/lib/booking/reserve.ts";
import { addDaysYmd, atLocalMinute, civilInZone, todayYmd, weekdayOfYmd, ymd } from "@/lib/booking/time.ts";

export class DomainError extends Error {
  readonly status: number;
  readonly code: string;
  constructor(message: string, code: string, status = 400) {
    super(message);
    this.name = "DomainError";
    this.code = code;
    this.status = status;
  }
}

const hits = new Map<string, number[]>();

function rateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const recent = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (recent.length >= limit) {
    hits.set(key, recent);
    return false;
  }
  recent.push(now);
  hits.set(key, recent);
  return true;
}

function id(): string {
  return crypto.randomUUID();
}

function asRecord(input: unknown): Record<string, unknown> {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new DomainError("درخواست نامعتبر است", "VALIDATION");
  }
  return input as Record<string, unknown>;
}

function text(input: Record<string, unknown>, key: string, max: number, fallback = ""): string {
  const value = input[key];
  if (value == null) return fallback;
  if (typeof value !== "string") throw new DomainError("درخواست نامعتبر است", "VALIDATION");
  return value.trim().slice(0, max);
}

function intField(input: Record<string, unknown>, key: string, min: number, max: number): number {
  const value = input[key];
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < min || n > max) {
    throw new DomainError("مقدار عددی نامعتبر است", "VALIDATION");
  }
  return n;
}

function dayField(value: unknown): string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new DomainError("تاریخ نامعتبر است", "VALIDATION");
  }
  return value;
}

function isoOf(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  const date = new Date(String(value));
  if (Number.isNaN(date.getTime())) throw new DomainError("زمان نامعتبر است", "VALIDATION");
  return date.toISOString();
}

function assertZone(timeZone: string) {
  try {
    Intl.DateTimeFormat("en-US", { timeZone });
  } catch {
    throw new DomainError("منطقه زمانی نامعتبر است", "VALIDATION");
  }
}

function like(q: string): string {
  return `%${q.replace(/[\\%_]/g, "\\$&")}%`;
}

function isUnique(err: unknown): boolean {
  const code = (err as { code?: string })?.code;
  const message = err instanceof Error ? err.message : "";
  return code === "23505" || /duplicate key|unique/i.test(message);
}

async function audit(
  sql: Sql,
  actor: string,
  action: string,
  entity: string,
  entityId: string | null,
  businessId: string | null,
  detail: string,
) {
  await sql.query(
    `insert into audit_logs (id, actor_user_id, business_id, action, entity, entity_id, detail)
     values ($1,$2,$3,$4,$5,$6,$7)`,
    [id(), actor, businessId, action, entity, entityId, detail.slice(0, 300)],
  );
}

async function ensureProfile(sql: Sql, userId: string) {
  const users = await sql.query<{ name: string; email: string }>(
    `select name, email from "user" where id = $1`,
    [userId],
  );
  const name = users[0]?.name ?? "";
  await sql.query(
    `insert into profiles (user_id, display_name) values ($1, $2)
     on conflict (user_id) do nothing`,
    [userId, name.slice(0, 80)],
  );
  return { name, email: users[0]?.email ?? "" };
}

async function roleOf(sql: Sql, userId: string, businessId: string): Promise<string | null> {
  const rows = await sql.query<{ role: string }>(
    `select role from memberships where business_id = $1 and user_id = $2`,
    [businessId, userId],
  );
  return rows[0]?.role ?? null;
}

async function requireRole(sql: Sql, userId: string, businessId: string, roles: string[]) {
  const role = await roleOf(sql, userId, businessId);
  if (!role || !roles.includes(role)) {
    throw new DomainError("به این کسب‌وکار دسترسی ندارید", "FORBIDDEN", 403);
  }
  return role;
}

async function isAdmin(sql: Sql, userId: string): Promise<boolean> {
  const rows = await sql.query(`select user_id from platform_admins where user_id = $1`, [userId]);
  return rows.length > 0;
}

async function requireAdmin(sql: Sql, userId: string) {
  if (!(await isAdmin(sql, userId))) {
    throw new DomainError("دسترسی مدیر سامانه لازم است", "FORBIDDEN", 403);
  }
}

type Biz = {
  id: string;
  owner_user_id: string;
  name: string;
  slug: string;
  description: string;
  category_id: string | null;
  city: string;
  address: string;
  phone: string;
  timezone: string;
  status: string;
  status_reason: string;
  cancel_before_minutes: number;
  min_lead_minutes: number;
  max_horizon_days: number;
  slot_step_minutes: number;
  allow_any_staff: boolean;
  is_demo: boolean;
};

async function businessById(sql: Sql, businessId: string): Promise<Biz> {
  const rows = await sql.query<Biz>(`select * from businesses where id = $1`, [businessId]);
  if (!rows[0]) throw new DomainError("کسب‌وکار پیدا نشد", "NOT_FOUND", 404);
  return rows[0];
}

const FORMULA =
  "ظرفیت = جمع دقایق ساعت کاری منهای استراحت و روز تعطیل. اشغال‌شده = مدت خدمت به‌علاوه فاصله آماده‌سازی نوبت‌های در انتظار، تأییدشده و انجام‌شده. نوبت لغوشده یا عدم مراجعه ظرفیت را اشغال نمی‌کند. نوبت چندخدمتی در این نسخه محاسبه نمی‌شود.";

export async function listCategories() {
  const sql = await getSql();
  return sql.query<{ id: string; name: string; slug: string }>(
    `select id, name, slug from categories where active = true order by sort, name`,
  );
}

export async function listBusinesses(raw: unknown) {
  const input = asRecord(raw ?? {});
  const q = text(input, "q", 80);
  const category = text(input, "category", 40);
  const limit = Math.min(24, Math.max(1, Number(input.limit ?? 24) || 24));
  const offset = Math.max(0, Math.min(500, Number(input.offset ?? 0) || 0));
  const sql = await getSql();
  const items = await sql.query<{
    id: string;
    name: string;
    slug: string;
    city: string;
    description: string;
    category_name: string | null;
    is_demo: boolean;
  }>(
    `select b.id, b.name, b.slug, b.city, b.description, c.name as category_name, b.is_demo
     from businesses b
     left join categories c on c.id = b.category_id
     where b.status = 'active'
       and ($1 = '' or b.name ilike $2 escape '\\' or b.city ilike $2 escape '\\')
       and ($3 = '' or b.category_id = $3 or c.slug = $3)
     order by b.created_at desc
     limit $4 offset $5`,
    [q, like(q), category, limit, offset],
  );
  return { items, limit, offset };
}

export async function publicBusiness(slug: string) {
  const sql = await getSql();
  const rows = await sql.query<Biz>(`select * from businesses where slug = $1`, [slug.slice(0, 80)]);
  const biz = rows[0];
  if (!biz || biz.status !== "active") {
    throw new DomainError("این صفحه در دسترس نیست", "NOT_FOUND", 404);
  }
  return snapshot(sql, biz, false);
}

async function snapshot(sql: Sql, biz: Biz, manage: boolean) {
  const category = biz.category_id
    ? await sql.query<{ name: string }>(`select name from categories where id = $1`, [biz.category_id])
    : [];
  const branches = await sql.query<{ id: string; name: string; address: string }>(
    `select id, name, address from branches where business_id = $1 and active = true order by name`,
    [biz.id],
  );
  const services = await sql.query<{
    id: string;
    name: string;
    description: string;
    duration_minutes: number;
    buffer_minutes: number;
    price_toman: number;
    active: boolean;
  }>(
    `select id, name, description, duration_minutes, buffer_minutes, price_toman, active
     from services where business_id = $1 ${manage ? "" : "and active = true"} order by name`,
    [biz.id],
  );
  const staff = await sql.query<{ id: string; name: string; title: string; active: boolean }>(
    `select id, name, title, active from staff where business_id = $1 ${manage ? "" : "and active = true"} order by name`,
    [biz.id],
  );
  const links = await sql.query<{ staff_id: string; service_id: string }>(
    `select staff_id, service_id from staff_services
     where staff_id in (select id from staff where business_id = $1)`,
    [biz.id],
  );
  const hours = await sql.query<{ staff_id: string; weekday: number; start_min: number; end_min: number }>(
    `select staff_id, weekday, start_min, end_min from working_hours
     where staff_id in (select id from staff where business_id = $1)
     order by weekday, start_min`,
    [biz.id],
  );
  const breaks = await sql.query<{ staff_id: string; weekday: number; start_min: number; end_min: number }>(
    `select staff_id, weekday, start_min, end_min from breaks
     where staff_id in (select id from staff where business_id = $1)`,
    [biz.id],
  );
  const holidays = manage
    ? await sql.query<{ id: string; staff_id: string | null; date_local: string; note: string }>(
        `select id, staff_id, date_local::text as date_local, note from holidays
         where business_id = $1 order by date_local`,
        [biz.id],
      )
    : [];
  return {
    id: biz.id,
    name: biz.name,
    slug: biz.slug,
    description: biz.description,
    categoryId: biz.category_id,
    categoryName: category[0]?.name ?? "",
    city: biz.city,
    address: biz.address,
    phone: biz.phone,
    timezone: biz.timezone,
    status: biz.status,
    statusReason: manage ? biz.status_reason : "",
    cancelBeforeMinutes: biz.cancel_before_minutes,
    minLeadMinutes: biz.min_lead_minutes,
    maxHorizonDays: biz.max_horizon_days,
    slotStepMinutes: biz.slot_step_minutes,
    allowAnyStaff: biz.allow_any_staff,
    isDemo: biz.is_demo,
    branches,
    services: services.map((s) => ({
      id: s.id,
      name: s.name,
      description: s.description,
      durationMinutes: s.duration_minutes,
      bufferMinutes: s.buffer_minutes,
      priceToman: s.price_toman,
      active: s.active,
    })),
    staff: staff.map((s) => ({
      id: s.id,
      name: s.name,
      title: s.title,
      active: s.active,
      serviceIds: links.filter((l) => l.staff_id === s.id).map((l) => l.service_id),
      weekly: hours
        .filter((h) => h.staff_id === s.id)
        .map((h) => ({ weekday: h.weekday, startMin: h.start_min, endMin: h.end_min })),
      breaks: breaks
        .filter((b) => b.staff_id === s.id)
        .map((b) => ({ weekday: b.weekday, startMin: b.start_min, endMin: b.end_min })),
    })),
    holidays: holidays.map((h) => ({
      id: h.id,
      staffId: h.staff_id,
      date: String(h.date_local).slice(0, 10),
      note: h.note,
    })),
  };
}

async function calendars(
  sql: Sql,
  biz: Biz,
  serviceId: string,
  day: string,
  onlyStaff: string | null,
  ignoreBookingId: string | null,
): Promise<{ id: string; name: string; calendar: StaffCalendar }[]> {
  const staff = await sql.query<{ id: string; name: string }>(
    `select s.id, s.name
     from staff s
     join staff_services ss on ss.staff_id = s.id and ss.service_id = $2
     where s.business_id = $1 and s.active = true
       and ($3::text is null or s.id = $3)
     order by s.id`,
    [biz.id, serviceId, onlyStaff],
  );
  if (!staff.length) return [];
  const weekday = weekdayOfYmd(day, biz.timezone);
  const dayStart = atLocalMinute(day, 0, biz.timezone).toISOString();
  const dayEnd = atLocalMinute(day, 1440, biz.timezone).toISOString();
  const hours = await sql.query<{ staff_id: string; start_min: number; end_min: number }>(
    `select staff_id, start_min, end_min from working_hours
     where weekday = $2 and staff_id in (select id from staff where business_id = $1)`,
    [biz.id, weekday],
  );
  const breaks = await sql.query<{ staff_id: string; start_min: number; end_min: number }>(
    `select staff_id, start_min, end_min from breaks
     where weekday = $2 and staff_id in (select id from staff where business_id = $1)`,
    [biz.id, weekday],
  );
  const holidays = await sql.query<{ staff_id: string | null }>(
    `select staff_id from holidays where business_id = $1 and date_local = $2::date`,
    [biz.id, day],
  );
  const businessHoliday = holidays.some((h) => !h.staff_id);
  const busy = await sql.query<{ staff_id: string; starts_at: unknown; buffer_until: unknown }>(
    `select staff_id, starts_at, buffer_until from bookings
     where business_id = $1
       and status in ('confirmed', 'pending')
       and starts_at < $2::timestamptz
       and buffer_until > $3::timestamptz
       and ($4::text is null or id <> $4)`,
    [biz.id, dayEnd, dayStart, ignoreBookingId],
  );
  return staff.map((member) => ({
    id: member.id,
    name: member.name,
    calendar: {
      staffId: member.id,
      holiday: businessHoliday || holidays.some((h) => h.staff_id === member.id),
      windows: hours
        .filter((h) => h.staff_id === member.id)
        .map((h) => ({ start: h.start_min, end: h.end_min })),
      breaks: breaks
        .filter((b) => b.staff_id === member.id)
        .map((b) => ({ start: b.start_min, end: b.end_min })),
      busy: busy
        .filter((b) => b.staff_id === member.id)
        .map((b) => ({ startsAt: isoOf(b.starts_at), bufferUntil: isoOf(b.buffer_until) })),
    },
  }));
}

export async function availability(raw: unknown) {
  const input = asRecord(raw ?? {});
  const businessId = text(input, "businessId", 80);
  const serviceId = text(input, "serviceId", 80);
  const staffId = text(input, "staffId", 80) || null;
  const day = dayField(input.day);
  const sql = await getSql();
  const biz = await businessById(sql, businessId);
  if (biz.status !== "active") throw new DomainError("رزرو این کسب‌وکار ممکن نیست", "NOT_FOUND", 404);
  const services = await sql.query<{
    duration_minutes: number;
    buffer_minutes: number;
    active: boolean;
  }>(`select duration_minutes, buffer_minutes, active from services where id = $1 and business_id = $2`, [
    serviceId,
    biz.id,
  ]);
  const service = services[0];
  if (!service || !service.active) throw new DomainError("خدمت پیدا نشد", "NOT_FOUND", 404);
  const rows = await calendars(sql, biz, serviceId, day, staffId, null);
  const slots = dayAvailability({
    day,
    timeZone: biz.timezone,
    now: new Date(),
    durationMin: service.duration_minutes,
    bufferMin: service.buffer_minutes,
    stepMin: biz.slot_step_minutes,
    minLeadMinutes: biz.min_lead_minutes,
    maxHorizonDays: biz.max_horizon_days,
    staff: rows.map((r) => r.calendar),
  });
  const names = new Map(rows.map((r) => [r.id, r.name]));
  return {
    timezone: biz.timezone,
    slots: slots.map((slot) => ({
      start: slot.start,
      staff: slot.staffIds.map((sid) => ({ id: sid, name: names.get(sid) ?? "" })),
    })),
  };
}

export async function me(userId: string) {
  const sql = await getSql();
  const user = await ensureProfile(sql, userId);
  const profile = await sql.query<{
    display_name: string;
    phone: string;
    username: string | null;
    page_for: string | null;
    page_name: string | null;
    activity_name: string | null;
  }>(
    `select p.display_name, p.phone, p.username, p.page_for, p.page_name, c.name as activity_name
     from profiles p
     left join categories c on c.id = p.activity_id
     where p.user_id = $1`,
    [userId],
  );
  const admin = await isAdmin(sql, userId);
  const admins = await sql.query<{ n: number }>(`select count(*)::int as n from platform_admins`);
  const memberships = await sql.query<{
    business_id: string;
    role: string;
    name: string;
    slug: string;
    status: string;
  }>(
    `select m.business_id, m.role, b.name, b.slug, b.status
     from memberships m join businesses b on b.id = m.business_id
     where m.user_id = $1
     order by b.created_at`,
    [userId],
  );
  const unread = await sql.query<{ n: number }>(
    `select count(*)::int as n from notifications where user_id = $1 and read_at is null`,
    [userId],
  );
  return {
    profile: {
      displayName: profile[0]?.display_name || user.name,
      phone: profile[0]?.phone ?? "",
      email: user.email,
      username: profile[0]?.username ?? "",
      pageFor: profile[0]?.page_for ?? "",
      pageName: profile[0]?.page_name ?? "",
      activityName: profile[0]?.activity_name ?? "",
    },
    isAdmin: admin,
    canClaim: !admin && (admins[0]?.n ?? 0) === 0,
    unread: unread[0]?.n ?? 0,
    memberships: memberships.map((m) => ({
      businessId: m.business_id,
      role: m.role,
      name: m.name,
      slug: m.slug,
      status: m.status,
    })),
  };
}

export async function updateProfile(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const displayName = text(input, "displayName", 80);
  const phone = text(input, "phone", 20);
  if (displayName.length < 2) throw new DomainError("نام را وارد کنید", "VALIDATION");
  const sql = await getSql();
  await ensureProfile(sql, userId);
  try {
    await sql.query(`update profiles set display_name = $2, phone = $3 where user_id = $1`, [
      userId,
      displayName,
      phone,
    ]);
  } catch (err) {
    const message = err instanceof Error ? err.message : "";
    if (/unique|duplicate/i.test(message)) {
      throw new DomainError("این شماره برای حساب دیگری است", "CONFLICT", 409);
    }
    throw err;
  }
  return me(userId);
}

export async function claimAdmin(userId: string) {
  return withTransaction(async (sql) => {
    await sql.query(`select pg_advisory_xact_lock(481516)`);
    const existing = await sql.query(`select user_id from platform_admins where user_id = $1`, [userId]);
    if (existing.length) return { claimed: true };
    const count = await sql.query<{ n: number }>(`select count(*)::int as n from platform_admins`);
    if ((count[0]?.n ?? 0) > 0) {
      throw new DomainError("مدیر سامانه قبلاً تعیین شده است", "FORBIDDEN", 403);
    }
    await sql.query(`insert into platform_admins (user_id) values ($1)`, [userId]);
    await audit(sql, userId, "claim_admin", "platform_admin", userId, null, "اولین مدیر سامانه");
    return { claimed: true };
  });
}

function slugify(name: string): string {
  const base = name
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\p{L}\p{N}-]/gu, "")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40);
  return `${base || "biz"}-${crypto.randomUUID().slice(0, 8)}`;
}

async function insertBusiness(
  sql: Sql,
  userId: string,
  fields: {
    name: string;
    description: string;
    categoryId: string | null;
    city: string;
    address: string;
    phone: string;
    timezone: string;
    isDemo: boolean;
  },
) {
  const businessId = id();
  const branchId = id();
  await sql.query(
    `insert into businesses (
      id, owner_user_id, name, slug, description, category_id, city, address, phone, timezone, is_demo
    ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
    [
      businessId,
      userId,
      fields.name,
      slugify(fields.name),
      fields.description,
      fields.categoryId,
      fields.city,
      fields.address,
      fields.phone,
      fields.timezone,
      fields.isDemo,
    ],
  );
  await sql.query(
    `insert into memberships (business_id, user_id, role) values ($1,$2,'owner')`,
    [businessId, userId],
  );
  await sql.query(
    `insert into branches (id, business_id, name, address) values ($1,$2,'شعبه اصلی',$3)`,
    [branchId, businessId, fields.address],
  );
  await sql.query(
    `insert into subscriptions (id, business_id, plan, status) values ($1,$2,'free','none')`,
    [id(), businessId],
  );
  await audit(sql, userId, "create_business", "business", businessId, businessId, fields.name);
  return { businessId, branchId };
}

export async function provisionStartPage(
  userId: string,
  input: {
    pageName: string;
    phone: string;
    username: string;
    categoryId: string;
    pageFor: "self" | "business";
  },
) {
  return withTransaction(async (sql) => {
    const cat = await sql.query(`select id from categories where id = $1 and active = true`, [input.categoryId]);
    if (!cat.length) throw new DomainError("حوزه فعالیت نامعتبر است", "VALIDATION");
    await sql.query(
      `insert into profiles (user_id, display_name, phone, username, activity_id, page_for, page_name, has_password)
       values ($1,$2,$3,$4,$5,$6,$7,false)
       on conflict (user_id) do update set
         display_name = excluded.display_name,
         phone = excluded.phone,
         username = excluded.username,
         activity_id = excluded.activity_id,
         page_for = excluded.page_for,
         page_name = excluded.page_name`,
      [userId, input.pageName.slice(0, 80), input.phone, input.username, input.categoryId, input.pageFor, input.pageName.slice(0, 80)],
    );
    const created = await insertBusiness(sql, userId, {
      name: input.pageName.slice(0, 80),
      description: input.pageFor === "self" ? "صفحه شخصی" : "",
      categoryId: input.categoryId,
      city: "",
      address: "",
      phone: input.phone,
      timezone: "Asia/Tehran",
      isDemo: false,
    });
    return { businessId: created.businessId };
  });
}

export async function createBusiness(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const name = text(input, "name", 80);
  if (name.length < 2) throw new DomainError("نام کسب‌وکار را وارد کنید", "VALIDATION");
  const timezone = text(input, "timezone", 64, "Asia/Tehran");
  assertZone(timezone);
  const categoryId = text(input, "categoryId", 40) || null;
  return withTransaction(async (sql) => {
    await ensureProfile(sql, userId);
    if (categoryId) {
      const cat = await sql.query(`select id from categories where id = $1 and active = true`, [categoryId]);
      if (!cat.length) throw new DomainError("دسته‌بندی نامعتبر است", "VALIDATION");
    }
    const created = await insertBusiness(sql, userId, {
      name,
      description: text(input, "description", 2000),
      categoryId,
      city: text(input, "city", 60),
      address: text(input, "address", 200),
      phone: text(input, "phone", 20),
      timezone,
      isDemo: false,
    });
    return { businessId: created.businessId };
  });
}

export async function createDemo(userId: string) {
  return withTransaction(async (sql) => {
    await ensureProfile(sql, userId);
    const created = await insertBusiness(sql, userId, {
      name: "آرایشگاه نمونه سرو",
      description: "داده نمونه برای آشنایی با رزرو. این کسب‌وکار واقعی نیست و می‌توانید حذفش کنید.",
      categoryId: "cat-beauty",
      city: "تهران",
      address: "خیابان نمونه، پلاک ۱",
      phone: "02100000000",
      timezone: "Asia/Tehran",
      isDemo: true,
    });
    const services = [
      ["اصلاح مو", 45, 10, 350000],
      ["اصلاح ریش", 30, 5, 180000],
      ["رنگ مو", 90, 15, 900000],
    ] as const;
    const serviceIds: string[] = [];
    for (const [name, duration, buffer, price] of services) {
      const sid = id();
      serviceIds.push(sid);
      await sql.query(
        `insert into services (id, business_id, branch_id, name, duration_minutes, buffer_minutes, price_toman)
         values ($1,$2,$3,$4,$5,$6,$7)`,
        [sid, created.businessId, created.branchId, name, duration, buffer, price],
      );
    }
    for (const person of [
      ["سارا کریمی", "استایلیست"],
      ["رضا نوری", "اصلاح"],
    ] as const) {
      const staffId = id();
      await sql.query(
        `insert into staff (id, business_id, branch_id, name, title) values ($1,$2,$3,$4,$5)`,
        [staffId, created.businessId, created.branchId, person[0], person[1]],
      );
      for (const sid of serviceIds) {
        await sql.query(`insert into staff_services (staff_id, service_id) values ($1,$2)`, [staffId, sid]);
      }
      for (const weekday of [6, 0, 1, 2, 3, 4]) {
        await sql.query(
          `insert into working_hours (id, staff_id, weekday, start_min, end_min) values ($1,$2,$3,540,1080)`,
          [id(), staffId, weekday],
        );
        await sql.query(
          `insert into breaks (id, staff_id, weekday, start_min, end_min) values ($1,$2,$3,840,900)`,
          [id(), staffId, weekday],
        );
      }
    }
    return { businessId: created.businessId };
  });
}

export async function updateBusiness(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const businessId = text(input, "businessId", 80);
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner", "manager"]);
  const name = text(input, "name", 80);
  if (name.length < 2) throw new DomainError("نام کسب‌وکار را وارد کنید", "VALIDATION");
  const timezone = text(input, "timezone", 64, "Asia/Tehran");
  assertZone(timezone);
  const categoryId = text(input, "categoryId", 40) || null;
  await sql.query(
    `update businesses set name=$2, description=$3, category_id=$4, city=$5, address=$6, phone=$7,
      timezone=$8, cancel_before_minutes=$9, min_lead_minutes=$10, max_horizon_days=$11,
      slot_step_minutes=$12, allow_any_staff=$13
     where id=$1`,
    [
      businessId,
      name,
      text(input, "description", 2000),
      categoryId,
      text(input, "city", 60),
      text(input, "address", 200),
      text(input, "phone", 20),
      timezone,
      intField(input, "cancelBeforeMinutes", 0, 7 * 24 * 60),
      intField(input, "minLeadMinutes", 0, 7 * 24 * 60),
      intField(input, "maxHorizonDays", 1, 180),
      intField(input, "slotStepMinutes", 5, 60),
      Boolean(input.allowAnyStaff),
    ],
  );
  await audit(sql, userId, "update_business", "business", businessId, businessId, name);
  return { businessId };
}

export async function deleteBusiness(userId: string, businessId: string) {
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner"]);
  await audit(sql, userId, "delete_business", "business", businessId, businessId, "");
  await sql.query(`delete from businesses where id = $1 and owner_user_id = $2`, [businessId, userId]);
  return { deleted: true };
}

export async function manageBusiness(userId: string, businessId: string) {
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner", "manager", "staff"]);
  const biz = await businessById(sql, businessId);
  return snapshot(sql, biz, true);
}

export async function saveService(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const businessId = text(input, "businessId", 80);
  const name = text(input, "name", 80);
  if (name.length < 2) throw new DomainError("نام خدمت را وارد کنید", "VALIDATION");
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner", "manager"]);
  const branch = await sql.query<{ id: string }>(
    `select id from branches where business_id = $1 and active = true order by name limit 1`,
    [businessId],
  );
  const serviceId = text(input, "id", 80) || id();
  const duration = intField(input, "durationMinutes", 5, 480);
  const buffer = intField(input, "bufferMinutes", 0, 180);
  const price = intField(input, "priceToman", 0, 100_000_000);
  const description = text(input, "description", 1000);
  const active = input.active !== false;
  const existing = await sql.query(`select id from services where id = $1 and business_id = $2`, [
    serviceId,
    businessId,
  ]);
  if (existing.length) {
    await sql.query(
      `update services set name=$2, description=$3, duration_minutes=$4, buffer_minutes=$5, price_toman=$6, active=$7
       where id=$1 and business_id=$8`,
      [serviceId, name, description, duration, buffer, price, active, businessId],
    );
  } else {
    await sql.query(
      `insert into services (id, business_id, branch_id, name, description, duration_minutes, buffer_minutes, price_toman, active)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [serviceId, businessId, branch[0]?.id ?? null, name, description, duration, buffer, price, active],
    );
  }
  return { serviceId };
}

async function defaultSchedule(sql: Sql, staffId: string) {
  for (const weekday of [6, 0, 1, 2, 3, 4]) {
    await sql.query(
      `insert into working_hours (id, staff_id, weekday, start_min, end_min) values ($1,$2,$3,540,1080)`,
      [id(), staffId, weekday],
    );
  }
}

export async function saveStaff(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const businessId = text(input, "businessId", 80);
  const name = text(input, "name", 80);
  if (name.length < 2) throw new DomainError("نام همکار را وارد کنید", "VALIDATION");
  const serviceIds = Array.isArray(input.serviceIds)
    ? input.serviceIds.filter((s): s is string => typeof s === "string").slice(0, 30)
    : [];
  if (!serviceIds.length) throw new DomainError("حداقل یک خدمت را به همکار وصل کنید", "VALIDATION");
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner", "manager"]);
  const branch = await sql.query<{ id: string }>(
    `select id from branches where business_id = $1 order by name limit 1`,
    [businessId],
  );
  if (!branch[0]) throw new DomainError("شعبه پیدا نشد", "VALIDATION");
  const owned = await sql.query<{ id: string }>(`select id from services where business_id = $1`, [businessId]);
  const allowed = new Set(owned.map((row) => row.id));
  if (serviceIds.some((serviceId) => !allowed.has(serviceId))) {
    throw new DomainError("خدمت نامعتبر است", "VALIDATION");
  }
  const staffId = text(input, "id", 80) || id();
  const existing = await sql.query(`select id from staff where id = $1 and business_id = $2`, [
    staffId,
    businessId,
  ]);
  if (existing.length) {
    await sql.query(`update staff set name=$2, title=$3, active=$4 where id=$1 and business_id=$5`, [
      staffId,
      name,
      text(input, "title", 80),
      input.active !== false,
      businessId,
    ]);
  } else {
    await sql.query(
      `insert into staff (id, business_id, branch_id, name, title, active) values ($1,$2,$3,$4,$5,$6)`,
      [staffId, businessId, branch[0].id, name, text(input, "title", 80), input.active !== false],
    );
    await defaultSchedule(sql, staffId);
  }
  await sql.query(`delete from staff_services where staff_id = $1`, [staffId]);
  for (const serviceId of serviceIds) {
    await sql.query(`insert into staff_services (staff_id, service_id) values ($1,$2)`, [staffId, serviceId]);
  }
  return { staffId };
}

export async function saveSchedule(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const businessId = text(input, "businessId", 80);
  const staffId = text(input, "staffId", 80);
  const days = Array.isArray(input.days) ? input.days : [];
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner", "manager"]);
  const staff = await sql.query(`select id from staff where id = $1 and business_id = $2`, [staffId, businessId]);
  if (!staff.length) throw new DomainError("همکار پیدا نشد", "NOT_FOUND", 404);
  await sql.query(`delete from working_hours where staff_id = $1`, [staffId]);
  await sql.query(`delete from breaks where staff_id = $1`, [staffId]);
  for (const rawDay of days.slice(0, 7)) {
    const day = asRecord(rawDay);
    if (day.enabled === false) continue;
    const weekday = intField(day, "weekday", 0, 6);
    const startMin = intField(day, "startMin", 0, 1439);
    const endMin = intField(day, "endMin", 1, 1440);
    if (endMin <= startMin) throw new DomainError("ساعت پایان باید بعد از شروع باشد", "VALIDATION");
    await sql.query(
      `insert into working_hours (id, staff_id, weekday, start_min, end_min) values ($1,$2,$3,$4,$5)`,
      [id(), staffId, weekday, startMin, endMin],
    );
    if (day.breakStart == null || day.breakEnd == null || day.breakStart === "" || day.breakEnd === "") continue;
    const breakStart = intField(day, "breakStart", 0, 1439);
    const breakEnd = intField(day, "breakEnd", 1, 1440);
    if (breakEnd <= breakStart || breakStart < startMin || breakEnd > endMin) {
      throw new DomainError("بازه استراحت باید داخل ساعت کاری باشد", "VALIDATION");
    }
    await sql.query(
      `insert into breaks (id, staff_id, weekday, start_min, end_min) values ($1,$2,$3,$4,$5)`,
      [id(), staffId, weekday, breakStart, breakEnd],
    );
  }
  return { staffId };
}

export async function addHoliday(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const businessId = text(input, "businessId", 80);
  const date = dayField(input.date);
  const staffId = text(input, "staffId", 80) || null;
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner", "manager"]);
  if (staffId) {
    const staff = await sql.query(`select id from staff where id = $1 and business_id = $2`, [staffId, businessId]);
    if (!staff.length) throw new DomainError("همکار پیدا نشد", "NOT_FOUND", 404);
  }
  const holidayId = id();
  await sql.query(
    `insert into holidays (id, business_id, staff_id, date_local, note) values ($1,$2,$3,$4::date,$5)`,
    [holidayId, businessId, staffId, date, text(input, "note", 120)],
  );
  return { holidayId };
}

export async function removeHoliday(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const businessId = text(input, "businessId", 80);
  const holidayId = text(input, "holidayId", 80);
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner", "manager"]);
  await sql.query(`delete from holidays where id = $1 and business_id = $2`, [holidayId, businessId]);
  return { removed: true };
}

async function notify(
  sql: Sql,
  userIds: string[],
  message: { businessId: string; bookingId: string; kind: string; title: string; body: string },
) {
  for (const userId of [...new Set(userIds)].filter(Boolean)) {
    await sql.query(
      `insert into notifications (id, user_id, business_id, booking_id, kind, title, body, channel, status)
       values ($1,$2,$3,$4,$5,$6,$7,'in_app','recorded')`,
      [id(), userId, message.businessId, message.bookingId, message.kind, message.title, message.body],
    );
  }
  const payload = JSON.stringify({ bookingId: message.bookingId, kind: message.kind });
  for (const channel of ["sms", "email"]) {
    await sql.query(
      `insert into notification_jobs (id, channel, payload, status, last_error)
       values ($1,$2,$3,'skipped','no_provider')`,
      [id(), channel, payload],
    );
  }
}

async function memberUserIds(sql: Sql, businessId: string): Promise<string[]> {
  const rows = await sql.query<{ user_id: string }>(
    `select user_id from memberships where business_id = $1 and role in ('owner','manager')`,
    [businessId],
  );
  return rows.map((r) => r.user_id);
}

type BookingJoin = {
  id: string;
  business_id: string;
  service_id: string;
  staff_id: string;
  customer_id: string;
  customer_user_id: string | null;
  created_by_user_id: string;
  starts_at: unknown;
  ends_at: unknown;
  status: string;
  source: string;
  note: string;
  cancel_reason: string;
  service_name: string;
  staff_name: string;
  business_name: string;
  business_slug: string;
  timezone: string;
  customer_name: string;
  customer_phone: string;
  price_toman: number;
  duration_minutes: number;
};

const BOOKING_SELECT = `
  select b.id, b.business_id, b.service_id, b.staff_id, b.customer_id, b.customer_user_id,
         b.created_by_user_id, b.starts_at, b.ends_at, b.status, b.source, b.note, b.cancel_reason,
         s.name as service_name, st.name as staff_name, biz.name as business_name, biz.slug as business_slug,
         biz.timezone, c.name as customer_name, c.phone as customer_phone, s.price_toman, s.duration_minutes
  from bookings b
  join services s on s.id = b.service_id
  join staff st on st.id = b.staff_id
  join businesses biz on biz.id = b.business_id
  join customers c on c.id = b.customer_id
`;

function bookingDto(row: BookingJoin, revealCustomer: boolean) {
  return {
    id: row.id,
    businessId: row.business_id,
    businessName: row.business_name,
    businessSlug: row.business_slug,
    timezone: row.timezone,
    serviceId: row.service_id,
    serviceName: row.service_name,
    staffId: row.staff_id,
    staffName: row.staff_name,
    startsAt: isoOf(row.starts_at),
    endsAt: isoOf(row.ends_at),
    status: row.status,
    source: row.source,
    note: row.note,
    cancelReason: row.cancel_reason,
    priceToman: row.price_toman,
    durationMinutes: row.duration_minutes,
    customerName: revealCustomer ? row.customer_name : "",
    customerPhone: revealCustomer ? row.customer_phone : "",
    mine: true,
  };
}

async function loadBooking(sql: Sql, bookingId: string): Promise<BookingJoin> {
  const rows = await sql.query<BookingJoin>(`${BOOKING_SELECT} where b.id = $1`, [bookingId]);
  if (!rows[0]) throw new DomainError("نوبت پیدا نشد", "NOT_FOUND", 404);
  return rows[0];
}

export async function myBookings(userId: string) {
  const sql = await getSql();
  const rows = await sql.query<BookingJoin>(
    `${BOOKING_SELECT} where b.customer_user_id = $1 order by b.starts_at desc limit 100`,
    [userId],
  );
  return rows.map((row) => bookingDto(row, true));
}

export async function businessBookings(userId: string, raw: unknown) {
  const input = asRecord(raw ?? {});
  const businessId = text(input, "businessId", 80);
  const status = text(input, "status", 20);
  const day = text(input, "day", 10);
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner", "manager", "staff"]);
  const biz = await businessById(sql, businessId);
  let from = "1970-01-01T00:00:00.000Z";
  let to = "2999-01-01T00:00:00.000Z";
  if (day) {
    const safe = dayField(day);
    from = atLocalMinute(safe, 0, biz.timezone).toISOString();
    to = atLocalMinute(safe, 1440, biz.timezone).toISOString();
  }
  const rows = await sql.query<BookingJoin>(
    `${BOOKING_SELECT}
     where b.business_id = $1
       and ($2 = '' or b.status = $2)
       and b.starts_at >= $3::timestamptz
       and b.starts_at < $4::timestamptz
     order by b.starts_at
     limit 200`,
    [businessId, status, from, to],
  );
  return rows.map((row) => bookingDto(row, true));
}

async function customerForOnline(sql: Sql, businessId: string, userId: string) {
  await ensureProfile(sql, userId);
  const profile = await sql.query<{ display_name: string; phone: string }>(
    `select display_name, phone from profiles where user_id = $1`,
    [userId],
  );
  const name = profile[0]?.display_name || "مشتری";
  const phone = profile[0]?.phone ?? "";
  const found = await sql.query<{ id: string }>(
    `select id from customers where business_id = $1 and user_id = $2`,
    [businessId, userId],
  );
  if (found[0]) {
    await sql.query(`update customers set name = $2, phone = $3 where id = $1`, [found[0].id, name, phone]);
    return found[0].id;
  }
  const customerId = id();
  await sql.query(
    `insert into customers (id, business_id, user_id, name, phone) values ($1,$2,$3,$4,$5)`,
    [customerId, businessId, userId, name, phone],
  );
  return customerId;
}

async function customerForManual(sql: Sql, businessId: string, name: string, phone: string) {
  if (phone) {
    const found = await sql.query<{ id: string }>(
      `select id from customers where business_id = $1 and phone = $2 and user_id is null limit 1`,
      [businessId, phone],
    );
    if (found[0]) {
      await sql.query(`update customers set name = $2 where id = $1`, [found[0].id, name]);
      return found[0].id;
    }
  }
  const customerId = id();
  await sql.query(
    `insert into customers (id, business_id, name, phone) values ($1,$2,$3,$4)`,
    [customerId, businessId, name, phone],
  );
  return customerId;
}

type ServiceRow = {
  id: string;
  branch_id: string | null;
  duration_minutes: number;
  buffer_minutes: number;
  active: boolean;
  name: string;
};

async function place(
  sql: Sql,
  userId: string,
  input: {
    businessId: string;
    serviceId: string;
    staffId: string | null;
    start: string;
    idempotencyKey: string;
    note: string;
    manual: { name: string; phone: string } | null;
  },
) {
  const bizRows = await sql.query<Biz>(`select * from businesses where id = $1 for update`, [input.businessId]);
  const biz = bizRows[0];
  if (!biz || biz.status !== "active") throw new DomainError("رزرو این کسب‌وکار ممکن نیست", "FORBIDDEN", 403);
  const replay = await sql.query<{ id: string; created_by_user_id: string; customer_user_id: string | null }>(
    `select id, created_by_user_id, customer_user_id from bookings
     where business_id = $1 and idempotency_key = $2`,
    [biz.id, input.idempotencyKey],
  );
  if (replay[0]) {
    if (replay[0].created_by_user_id !== userId && replay[0].customer_user_id !== userId) {
      throw new DomainError("این شناسه تکرار متعلق به شما نیست", "FORBIDDEN", 403);
    }
    const row = await loadBooking(sql, replay[0].id);
    return bookingDto(row, true);
  }
  if (input.manual) {
    await requireRole(sql, userId, biz.id, ["owner", "manager", "staff"]);
  }
  const services = await sql.query<ServiceRow>(
    `select id, branch_id, duration_minutes, buffer_minutes, active, name from services where id = $1 and business_id = $2`,
    [input.serviceId, biz.id],
  );
  const service = services[0];
  if (!service?.active) throw new DomainError("خدمت پیدا نشد", "NOT_FOUND", 404);
  const civilDay = (() => {
    const c = civilInZone(new Date(input.start), biz.timezone);
    return ymd(c.year, c.month, c.day);
  })();
  const rows = await calendars(sql, biz, service.id, civilDay, input.staffId, null);
  if (input.staffId == null && !biz.allow_any_staff) {
    throw new DomainError("انتخاب متخصص برای این کسب‌وکار الزامی است", "VALIDATION");
  }
  const slots = dayAvailability({
    day: civilDay,
    timeZone: biz.timezone,
    now: new Date(),
    durationMin: service.duration_minutes,
    bufferMin: service.buffer_minutes,
    stepMin: biz.slot_step_minutes,
    minLeadMinutes: biz.min_lead_minutes,
    maxHorizonDays: biz.max_horizon_days,
    staff: rows.map((r) => r.calendar),
  });
  const wanted = new Date(input.start).getTime();
  const match = slots.find((slot) => new Date(slot.start).getTime() === wanted);
  if (!match) throw new DomainError("این زمان دیگر آزاد نیست", "SLOT_TAKEN", 409);
  const chosen = input.staffId && match.staffIds.includes(input.staffId) ? input.staffId : match.staffIds[0];
  if (!chosen) throw new DomainError("متخصصی برای این زمان آزاد نیست", "SLOT_TAKEN", 409);
  const branchId =
    service.branch_id ??
    (
      await sql.query<{ branch_id: string }>(`select branch_id from staff where id = $1`, [chosen])
    )[0]?.branch_id;
  if (!branchId) throw new DomainError("شعبه خدمت مشخص نیست", "VALIDATION");
  const customerId = input.manual
    ? await customerForManual(sql, biz.id, input.manual.name, input.manual.phone)
    : await customerForOnline(sql, biz.id, userId);
  const starts = new Date(wanted);
  const ends = new Date(wanted + service.duration_minutes * 60_000);
  const bufferUntil = new Date(wanted + (service.duration_minutes + service.buffer_minutes) * 60_000);
  const bookingId = id();
  const placed = await insertBookingIfFree(sql, {
    id: bookingId,
    businessId: biz.id,
    branchId,
    serviceId: service.id,
    staffId: chosen,
    customerId,
    customerUserId: input.manual ? null : userId,
    createdByUserId: userId,
    startsAt: starts.toISOString(),
    endsAt: ends.toISOString(),
    bufferUntil: bufferUntil.toISOString(),
    status: "confirmed",
    source: input.manual ? "manual" : "online",
    idempotencyKey: input.idempotencyKey,
    note: input.note,
  });
  if (placed === "conflict") throw new DomainError("این زمان همین حالا رزرو شد", "SLOT_TAKEN", 409);
  if (placed === "missing_staff") throw new DomainError("متخصص در دسترس نیست", "SLOT_TAKEN", 409);
  const staffName = rows.find((r) => r.id === chosen)?.name ?? "";
  const when = new Intl.DateTimeFormat("fa-IR", {
    timeZone: biz.timezone,
    dateStyle: "medium",
    timeStyle: "short",
  }).format(starts);
  await notify(sql, [input.manual ? "" : userId, ...(await memberUserIds(sql, biz.id))], {
    businessId: biz.id,
    bookingId,
    kind: "booking_created",
    title: "نوبت ثبت شد",
    body: `${service.name} با ${staffName}، ${when}. این پیام فقط اعلان داخلی است.`,
  });
  await audit(sql, userId, "create_booking", "booking", bookingId, biz.id, service.name);
  const row = await loadBooking(sql, bookingId);
  return bookingDto(row, true);
}

function parseBooking(raw: unknown) {
  const input = asRecord(raw);
  const manualName = text(input, "customerName", 80);
  const manual = input.manual === true;
  if (manual && manualName.length < 2) throw new DomainError("نام مشتری را وارد کنید", "VALIDATION");
  const key = text(input, "idempotencyKey", 80);
  if (!/^[a-zA-Z0-9_:-]{8,80}$/.test(key)) {
    throw new DomainError("شناسه تکرار درخواست نامعتبر است", "VALIDATION");
  }
  const start = isoOf(input.start);
  return {
    businessId: text(input, "businessId", 80),
    serviceId: text(input, "serviceId", 80),
    staffId: text(input, "staffId", 80) || null,
    start,
    idempotencyKey: key,
    note: text(input, "note", 500),
    manual: manual ? { name: manualName, phone: text(input, "customerPhone", 20) } : null,
  };
}

export async function createBooking(userId: string, raw: unknown) {
  if (!rateLimit(`book:${userId}`, 10, 60_000)) {
    throw new DomainError("تعداد درخواست زیاد است. کمی بعد دوباره تلاش کنید.", "RATE_LIMIT", 429);
  }
  const input = parseBooking(raw);
  try {
    return await withTransaction((sql) => place(sql, userId, input));
  } catch (err) {
    if (!isUnique(err)) throw err;
    const sql = await getSql();
    const replay = await sql.query<{ id: string; created_by_user_id: string; customer_user_id: string | null }>(
      `select id, created_by_user_id, customer_user_id from bookings
       where business_id = $1 and idempotency_key = $2`,
      [input.businessId, input.idempotencyKey],
    );
    if (!replay[0]) throw err;
    if (replay[0].created_by_user_id !== userId && replay[0].customer_user_id !== userId) {
      throw new DomainError("این شناسه تکرار متعلق به شما نیست", "FORBIDDEN", 403);
    }
    const row = await loadBooking(sql, replay[0].id);
    return bookingDto(row, true);
  }
}

const NEXT: Record<string, string[]> = {
  pending: ["confirmed", "cancelled"],
  confirmed: ["completed", "cancelled", "no_show"],
  completed: [],
  cancelled: [],
  no_show: [],
};

async function assertCustomerWindow(sql: Sql, row: BookingJoin) {
  const biz = await businessById(sql, row.business_id);
  const starts = new Date(isoOf(row.starts_at)).getTime();
  if (starts - Date.now() < biz.cancel_before_minutes * 60_000) {
    throw new DomainError("مهلت لغو یا جابه‌جایی این نوبت گذشته است", "POLICY", 409);
  }
}

export async function setBookingStatus(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const bookingId = text(input, "bookingId", 80);
  const status = text(input, "status", 20);
  const reason = text(input, "reason", 200);
  return withTransaction(async (sql) => {
    const row = await loadBooking(sql, bookingId);
    const role = await roleOf(sql, userId, row.business_id);
    const isCustomer = row.customer_user_id === userId;
    if (!role && !isCustomer) throw new DomainError("به این نوبت دسترسی ندارید", "FORBIDDEN", 403);
    if (!role && status !== "cancelled") {
      throw new DomainError("فقط کسب‌وکار می‌تواند این وضعیت را عوض کند", "FORBIDDEN", 403);
    }
    if (!(NEXT[row.status] ?? []).includes(status)) {
      throw new DomainError("این تغییر وضعیت مجاز نیست", "POLICY", 409);
    }
    if (isCustomer && !role && status === "cancelled") await assertCustomerWindow(sql, row);
    await sql.query(
      `update bookings set status = $2, cancel_reason = $3, updated_at = now() where id = $1`,
      [bookingId, status, status === "cancelled" ? reason : row.cancel_reason],
    );
    const titles: Record<string, string> = {
      cancelled: "نوبت لغو شد",
      completed: "نوبت انجام شد",
      no_show: "عدم مراجعه ثبت شد",
      confirmed: "نوبت تأیید شد",
    };
    await notify(sql, [row.customer_user_id ?? "", ...(await memberUserIds(sql, row.business_id))], {
      businessId: row.business_id,
      bookingId,
      kind: `booking_${status}`,
      title: titles[status] ?? "وضعیت نوبت عوض شد",
      body: `${row.service_name}. این پیام فقط اعلان داخلی است.`,
    });
    await audit(sql, userId, "booking_status", "booking", bookingId, row.business_id, status);
    const next = await loadBooking(sql, bookingId);
    return bookingDto(next, Boolean(role) || isCustomer);
  });
}

export async function rescheduleBooking(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const bookingId = text(input, "bookingId", 80);
  const staffId = text(input, "staffId", 80) || null;
  const start = isoOf(input.start);
  return withTransaction(async (sql) => {
    const row = await loadBooking(sql, bookingId);
    const biz = await businessById(sql, row.business_id);
    await sql.query(`select id from businesses where id = $1 for update`, [biz.id]);
    const role = await roleOf(sql, userId, biz.id);
    const isCustomer = row.customer_user_id === userId;
    if (!role && !isCustomer) throw new DomainError("به این نوبت دسترسی ندارید", "FORBIDDEN", 403);
    if (!["confirmed", "pending"].includes(row.status)) {
      throw new DomainError("این نوبت قابل جابه‌جایی نیست", "POLICY", 409);
    }
    if (isCustomer && !role) await assertCustomerWindow(sql, row);
    const services = await sql.query<ServiceRow>(
      `select id, branch_id, duration_minutes, buffer_minutes, active, name from services where id = $1`,
      [row.service_id],
    );
    const service = services[0];
    if (!service?.active) throw new DomainError("خدمت دیگر فعال نیست", "POLICY", 409);
    const civil = civilInZone(new Date(start), biz.timezone);
    const civilDay = ymd(civil.year, civil.month, civil.day);
    const people = await calendars(sql, biz, service.id, civilDay, staffId, bookingId);
    const slots = dayAvailability({
      day: civilDay,
      timeZone: biz.timezone,
      now: new Date(),
      durationMin: service.duration_minutes,
      bufferMin: service.buffer_minutes,
      stepMin: biz.slot_step_minutes,
      minLeadMinutes: biz.min_lead_minutes,
      maxHorizonDays: biz.max_horizon_days,
      staff: people.map((p) => p.calendar),
    });
    const wanted = new Date(start).getTime();
    const match = slots.find((slot) => new Date(slot.start).getTime() === wanted);
    if (!match) throw new DomainError("زمان جدید آزاد نیست", "SLOT_TAKEN", 409);
    const chosen = staffId && match.staffIds.includes(staffId) ? staffId : match.staffIds[0];
    if (!chosen) throw new DomainError("متخصصی برای این زمان آزاد نیست", "SLOT_TAKEN", 409);
    const ends = new Date(wanted + service.duration_minutes * 60_000);
    const bufferUntil = new Date(wanted + (service.duration_minutes + service.buffer_minutes) * 60_000);
    const staffBranch = await sql.query<{ branch_id: string }>(`select branch_id from staff where id = $1`, [
      chosen,
    ]);
    const branchId = service.branch_id ?? staffBranch[0]?.branch_id;
    if (!branchId) throw new DomainError("شعبه خدمت مشخص نیست", "VALIDATION");
    const moved = await moveBookingIfFree(sql, {
      bookingId,
      businessId: biz.id,
      staffId: chosen,
      startsAt: new Date(wanted).toISOString(),
      endsAt: ends.toISOString(),
      bufferUntil: bufferUntil.toISOString(),
      serviceId: service.id,
      branchId,
    });
    if (moved !== "ok") throw new DomainError("زمان جدید همین حالا گرفته شد", "SLOT_TAKEN", 409);
    await notify(sql, [row.customer_user_id ?? "", ...(await memberUserIds(sql, biz.id))], {
      businessId: biz.id,
      bookingId,
      kind: "booking_rescheduled",
      title: "نوبت جابه‌جا شد",
      body: `${row.service_name}. این پیام فقط اعلان داخلی است.`,
    });
    await audit(sql, userId, "reschedule", "booking", bookingId, biz.id, "");
    const next = await loadBooking(sql, bookingId);
    return bookingDto(next, Boolean(role) || isCustomer);
  });
}

export async function listCustomers(userId: string, raw: unknown) {
  const input = asRecord(raw ?? {});
  const businessId = text(input, "businessId", 80);
  const q = text(input, "q", 80);
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner", "manager", "staff"]);
  const rows = await sql.query<{
    id: string;
    name: string;
    phone: string;
    notes: string;
    visits: number;
    last_visit: unknown;
  }>(
    `select c.id, c.name, c.phone, c.notes,
        count(b.id)::int as visits,
        max(b.starts_at) as last_visit
     from customers c
     left join bookings b on b.customer_id = c.id and b.status <> 'cancelled'
     where c.business_id = $1
       and ($2 = '' or c.name ilike $3 escape '\\' or c.phone ilike $3 escape '\\')
     group by c.id
     order by c.created_at desc
     limit 80`,
    [businessId, q, like(q)],
  );
  return rows.map((row) => ({
    id: row.id,
    name: row.name,
    phone: row.phone,
    notes: row.notes,
    visits: row.visits,
    lastVisit: row.last_visit ? isoOf(row.last_visit) : null,
  }));
}

export async function saveCustomer(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const businessId = text(input, "businessId", 80);
  const name = text(input, "name", 80);
  if (name.length < 2) throw new DomainError("نام مشتری را وارد کنید", "VALIDATION");
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner", "manager", "staff"]);
  const customerId = text(input, "id", 80) || id();
  const existing = await sql.query(`select id from customers where id = $1 and business_id = $2`, [
    customerId,
    businessId,
  ]);
  if (existing.length) {
    await sql.query(`update customers set name=$2, phone=$3, notes=$4 where id=$1`, [
      customerId,
      name,
      text(input, "phone", 20),
      text(input, "notes", 500),
    ]);
  } else {
    await sql.query(
      `insert into customers (id, business_id, name, phone, notes) values ($1,$2,$3,$4,$5)`,
      [customerId, businessId, name, text(input, "phone", 20), text(input, "notes", 500)],
    );
  }
  return { customerId };
}

export async function dashboard(userId: string, raw: unknown) {
  const input = asRecord(raw ?? {});
  const businessId = text(input, "businessId", 80);
  const sql = await getSql();
  await requireRole(sql, userId, businessId, ["owner", "manager", "staff"]);
  const biz = await businessById(sql, businessId);
  const from = text(input, "from", 10) || todayYmd(biz.timezone);
  const to = text(input, "to", 10) || addDaysYmd(dayField(from), 6, biz.timezone);
  const start = atLocalMinute(dayField(from), 0, biz.timezone).toISOString();
  const end = atLocalMinute(dayField(to), 1440, biz.timezone).toISOString();
  const counts = await sql.query<{ status: string; n: number }>(
    `select status, count(*)::int as n from bookings
     where business_id = $1 and starts_at >= $2::timestamptz and starts_at < $3::timestamptz
     group by status`,
    [businessId, start, end],
  );
  const byStatus: Record<string, number> = {};
  for (const row of counts) byStatus[row.status] = row.n;
  const staff = await sql.query<{ id: string }>(`select id from staff where business_id = $1 and active = true`, [
    businessId,
  ]);
  const hours = await sql.query<{ staff_id: string; weekday: number; start_min: number; end_min: number }>(
    `select staff_id, weekday, start_min, end_min from working_hours
     where staff_id in (select id from staff where business_id = $1 and active = true)`,
    [businessId],
  );
  const breaks = await sql.query<{ staff_id: string; weekday: number; start_min: number; end_min: number }>(
    `select staff_id, weekday, start_min, end_min from breaks
     where staff_id in (select id from staff where business_id = $1)`,
    [businessId],
  );
  const holidays = await sql.query<{ staff_id: string | null; date_local: string }>(
    `select staff_id, date_local::text as date_local from holidays
     where business_id = $1 and date_local >= $2::date and date_local <= $3::date`,
    [businessId, from, to],
  );
  const occupied = await sql.query<{ staff_id: string; starts_at: unknown; buffer_until: unknown }>(
    `select staff_id, starts_at, buffer_until from bookings
     where business_id = $1 and status in ('pending','confirmed','completed')
       and buffer_until > $2::timestamptz and starts_at < $3::timestamptz`,
    [businessId, start, end],
  );
  let availableMinutes = 0;
  let occupiedMinutes = 0;
  for (let day = dayField(from); day <= dayField(to); day = addDaysYmd(day, 1, biz.timezone)) {
    const weekday = weekdayOfYmd(day, biz.timezone);
    const dayHolidays = holidays.filter((h) => String(h.date_local).slice(0, 10) === day);
    const closed = dayHolidays.some((h) => !h.staff_id);
    for (const member of staff) {
      if (closed || dayHolidays.some((h) => h.staff_id === member.id)) continue;
      const windows = hours.filter((h) => h.staff_id === member.id && h.weekday === weekday);
      const rests = breaks.filter((b) => b.staff_id === member.id && b.weekday === weekday);
      let minutes = windows.reduce((sum, w) => sum + (w.end_min - w.start_min), 0);
      for (const rest of rests) {
        for (const w of windows) {
          const s = Math.max(w.start_min, rest.start_min);
          const e = Math.min(w.end_min, rest.end_min);
          if (e > s) minutes -= e - s;
        }
      }
      availableMinutes += Math.max(0, minutes);
    }
    occupiedMinutes += occupiedMinutesOnDay(
      occupied.map((row) => ({ startsAt: isoOf(row.starts_at), bufferUntil: isoOf(row.buffer_until) })),
      day,
      biz.timezone,
    );
    if (day === to) break;
  }
  const today = todayYmd(biz.timezone);
  const todayStart = atLocalMinute(today, 0, biz.timezone).toISOString();
  const todayEnd = atLocalMinute(today, 1440, biz.timezone).toISOString();
  const todayRows = await sql.query<{ n: number }>(
    `select count(*)::int as n from bookings
     where business_id = $1 and status in ('confirmed','pending')
       and starts_at >= $2::timestamptz and starts_at < $3::timestamptz`,
    [businessId, todayStart, todayEnd],
  );
  return {
    from,
    to,
    timezone: biz.timezone,
    today: todayRows[0]?.n ?? 0,
    byStatus,
    capacity: {
      availableMinutes,
      occupiedMinutes,
      freeMinutes: Math.max(0, availableMinutes - occupiedMinutes),
      formula: FORMULA,
    },
  };
}

export async function myNotifications(userId: string) {
  const sql = await getSql();
  const rows = await sql.query<{
    id: string;
    title: string;
    body: string;
    kind: string;
    channel: string;
    read_at: unknown;
    created_at: unknown;
  }>(
    `select id, title, body, kind, channel, read_at, created_at
     from notifications where user_id = $1 order by created_at desc limit 40`,
    [userId],
  );
  return rows.map((row) => ({
    id: row.id,
    title: row.title,
    body: row.body,
    kind: row.kind,
    channel: row.channel,
    read: Boolean(row.read_at),
    createdAt: isoOf(row.created_at),
  }));
}

export async function markNotificationRead(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const notificationId = text(input, "notificationId", 80);
  const sql = await getSql();
  if (notificationId) {
    await sql.query(
      `update notifications set read_at = now() where id = $1 and user_id = $2 and read_at is null`,
      [notificationId, userId],
    );
  } else {
    await sql.query(`update notifications set read_at = now() where user_id = $1 and read_at is null`, [userId]);
  }
  return { ok: true };
}

export async function adminOverview(userId: string) {
  const sql = await getSql();
  await requireAdmin(sql, userId);
  const users = await sql.query<{ n: number }>(`select count(*)::int as n from "user"`);
  const businesses = await sql.query<{ status: string; n: number }>(
    `select status, count(*)::int as n from businesses group by status`,
  );
  const bookings = await sql.query<{ status: string; n: number }>(
    `select status, count(*)::int as n from bookings group by status`,
  );
  const settings = await sql.query<{ key: string; value: string }>(
    `select key, value from platform_settings order by key`,
  );
  return {
    users: users[0]?.n ?? 0,
    businesses: Object.fromEntries(businesses.map((b) => [b.status, b.n])),
    bookings: Object.fromEntries(bookings.map((b) => [b.status, b.n])),
    settings,
    note: "ارسال پیامک و ایمیل وصل نیست. ردیف‌های کار با وضعیت skipped ارسال واقعی نیستند.",
  };
}

export async function adminUsers(userId: string, raw: unknown) {
  const q = text(asRecord(raw ?? {}), "q", 80);
  const sql = await getSql();
  await requireAdmin(sql, userId);
  const rows = await sql.query<{
    id: string;
    name: string;
    email: string;
    created_at: unknown;
    is_admin: boolean;
  }>(
    `select u.id, u.name, u.email, u."createdAt" as created_at,
        exists(select 1 from platform_admins a where a.user_id = u.id) as is_admin
     from "user" u
     where ($1 = '' or u.name ilike $2 escape '\\' or u.email ilike $2 escape '\\')
     order by u."createdAt" desc
     limit 50`,
    [q, like(q)],
  );
  return rows.map((row) => ({
    id: row.id,
    name: row.name,
    email: row.email,
    createdAt: isoOf(row.created_at),
    isAdmin: row.is_admin,
  }));
}

export async function adminBusinesses(userId: string, raw: unknown) {
  const q = text(asRecord(raw ?? {}), "q", 80);
  const sql = await getSql();
  await requireAdmin(sql, userId);
  return sql.query<{
    id: string;
    name: string;
    slug: string;
    status: string;
    status_reason: string;
    city: string;
    is_demo: boolean;
  }>(
    `select id, name, slug, status, status_reason, city, is_demo from businesses
     where ($1 = '' or name ilike $2 escape '\\' or city ilike $2 escape '\\')
     order by created_at desc limit 80`,
    [q, like(q)],
  );
}

export async function setBusinessModeration(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const businessId = text(input, "businessId", 80);
  const status = text(input, "status", 20);
  const reason = text(input, "reason", 300);
  if (!["active", "inactive", "suspended"].includes(status)) {
    throw new DomainError("وضعیت نامعتبر است", "VALIDATION");
  }
  if (status !== "active" && reason.length < 3) {
    throw new DomainError("دلیل غیرفعال‌سازی یا تعلیق را بنویسید", "VALIDATION");
  }
  const sql = await getSql();
  await requireAdmin(sql, userId);
  const updated = await sql.query(`update businesses set status=$2, status_reason=$3 where id=$1 returning id`, [
    businessId,
    status,
    status === "active" ? "" : reason,
  ]);
  if (!updated.length) throw new DomainError("کسب‌وکار پیدا نشد", "NOT_FOUND", 404);
  await audit(sql, userId, "moderate_business", "business", businessId, businessId, `${status}: ${reason}`);
  return { businessId, status };
}

export async function adminCategories(userId: string) {
  const sql = await getSql();
  await requireAdmin(sql, userId);
  return sql.query<{ id: string; name: string; slug: string; active: boolean; sort: number }>(
    `select id, name, slug, active, sort from categories order by sort, name`,
  );
}

export async function saveCategory(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const name = text(input, "name", 60);
  if (name.length < 2) throw new DomainError("نام دسته را وارد کنید", "VALIDATION");
  const slug = text(input, "slug", 40).toLowerCase().replace(/[^a-z0-9-]/g, "") || `cat-${id().slice(0, 8)}`;
  const sql = await getSql();
  await requireAdmin(sql, userId);
  const categoryId = text(input, "id", 40) || id();
  const existing = await sql.query(`select id from categories where id = $1`, [categoryId]);
  if (existing.length) {
    await sql.query(`update categories set name=$2, slug=$3, active=$4 where id=$1`, [
      categoryId,
      name,
      slug,
      input.active !== false,
    ]);
  } else {
    await sql.query(`insert into categories (id, name, slug, sort, active) values ($1,$2,$3,50,$4)`, [
      categoryId,
      name,
      slug,
      input.active !== false,
    ]);
  }
  await audit(sql, userId, "save_category", "category", categoryId, null, name);
  return { categoryId };
}

export async function adminAudit(userId: string) {
  const sql = await getSql();
  await requireAdmin(sql, userId);
  const logs = await sql.query<{
    id: string;
    actor_user_id: string;
    action: string;
    entity: string;
    entity_id: string | null;
    detail: string;
    created_at: unknown;
  }>(
    `select id, actor_user_id, action, entity, entity_id, detail, created_at
     from audit_logs order by created_at desc limit 80`,
  );
  const jobs = await sql.query<{ channel: string; status: string; n: number }>(
    `select channel, status, count(*)::int as n from notification_jobs group by channel, status`,
  );
  return {
    logs: logs.map((row) => ({
      id: row.id,
      actorUserId: row.actor_user_id,
      action: row.action,
      entity: row.entity,
      entityId: row.entity_id,
      detail: row.detail,
      createdAt: isoOf(row.created_at),
    })),
    jobs,
    errorLog: "گزارش خطای متمرکز به سرویس خارجی وصل نیست. رخدادهای مهم همین‌جا در حسابرسی است.",
  };
}

export async function saveSettings(userId: string, raw: unknown) {
  const input = asRecord(raw);
  const sql = await getSql();
  await requireAdmin(sql, userId);
  for (const key of ["platform_name", "support_email"] as const) {
    if (typeof input[key] !== "string") continue;
    await sql.query(
      `insert into platform_settings (key, value) values ($1,$2)
       on conflict (key) do update set value = excluded.value, updated_at = now()`,
      [key, text(input, key, 120)],
    );
  }
  await audit(sql, userId, "save_settings", "platform_settings", null, null, "");
  return adminOverview(userId);
}
