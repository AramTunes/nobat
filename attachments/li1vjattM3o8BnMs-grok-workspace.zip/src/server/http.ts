import { assertSameSiteRequest } from "@/lib/auth/isolation.server";
import { requireUserId, UnauthorizedError } from "@/lib/auth/verify.server";
import { DomainError } from "./domain";
import * as domain from "./domain";

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

async function readBody(request: Request): Promise<unknown> {
  if (request.method === "GET") return {};
  const text = await request.text();
  if (!text) return {};
  try {
    return JSON.parse(text) as unknown;
  } catch {
    throw new DomainError("بدنه درخواست JSON نیست", "VALIDATION");
  }
}

async function userId(): Promise<string> {
  assertSameSiteRequest();
  try {
    return await requireUserId();
  } catch (err) {
    if (err instanceof UnauthorizedError || (err as Error)?.message === "Unauthorized") {
      throw new DomainError("برای ادامه وارد شوید", "UNAUTHORIZED", 401);
    }
    throw err;
  }
}

export async function handleApi(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/$/, "") || "/";
  const rest = path.startsWith("/api/v1") ? path.slice("/api/v1".length) || "/" : path;
  try {
    if (request.method === "GET" && rest === "/health") {
      return json(200, { ok: true, data: { service: "nobatak", time: new Date().toISOString() } });
    }
    if (request.method === "GET" && rest === "/categories") {
      return json(200, { ok: true, data: await domain.listCategories() });
    }
    if (request.method === "GET" && rest === "/businesses") {
      return json(200, {
        ok: true,
        data: await domain.listBusinesses({
          q: url.searchParams.get("q") ?? "",
          category: url.searchParams.get("category") ?? "",
          limit: Number(url.searchParams.get("limit") ?? 24),
          offset: Number(url.searchParams.get("offset") ?? 0),
        }),
      });
    }
    const slug = /^\/businesses\/([^/]+)$/.exec(rest);
    if (request.method === "GET" && slug) {
      return json(200, { ok: true, data: await domain.publicBusiness(decodeURIComponent(slug[1])) });
    }
    if (request.method === "GET" && rest === "/availability") {
      return json(200, {
        ok: true,
        data: await domain.availability({
          businessId: url.searchParams.get("businessId") ?? "",
          serviceId: url.searchParams.get("serviceId") ?? "",
          staffId: url.searchParams.get("staffId") ?? "",
          day: url.searchParams.get("day") ?? "",
        }),
      });
    }

    const actor = await userId();
    const body = await readBody(request);

    if (request.method === "GET" && rest === "/me") return json(200, { ok: true, data: await domain.me(actor) });
    if (request.method === "GET" && rest === "/me/bookings") {
      return json(200, { ok: true, data: await domain.myBookings(actor) });
    }
    if (request.method === "GET" && rest === "/me/notifications") {
      return json(200, { ok: true, data: await domain.myNotifications(actor) });
    }
    if (request.method === "POST" && rest === "/bookings") {
      return json(200, { ok: true, data: await domain.createBooking(actor, body) });
    }
    const cancel = /^\/bookings\/([^/]+)\/cancel$/.exec(rest);
    if (request.method === "POST" && cancel) {
      const payload = (body ?? {}) as Record<string, unknown>;
      return json(200, {
        ok: true,
        data: await domain.setBookingStatus(actor, {
          bookingId: decodeURIComponent(cancel[1]),
          status: "cancelled",
          reason: payload.reason ?? "",
        }),
      });
    }
    const move = /^\/bookings\/([^/]+)\/reschedule$/.exec(rest);
    if (request.method === "POST" && move) {
      const payload = (body ?? {}) as Record<string, unknown>;
      return json(200, {
        ok: true,
        data: await domain.rescheduleBooking(actor, {
          ...payload,
          bookingId: decodeURIComponent(move[1]),
        }),
      });
    }
    if (request.method === "POST" && rest === "/businesses") {
      return json(200, { ok: true, data: await domain.createBusiness(actor, body) });
    }
    if (request.method === "GET" && rest === "/admin/overview") {
      return json(200, { ok: true, data: await domain.adminOverview(actor) });
    }
    return json(404, { ok: false, error: { code: "NOT_FOUND", message: "مسیر پیدا نشد" } });
  } catch (err) {
    if (err instanceof DomainError) {
      return json(err.status, { ok: false, error: { code: err.code, message: err.message } });
    }
    console.error("[api]", err instanceof Error ? err.name : "error");
    return json(500, { ok: false, error: { code: "INTERNAL", message: "خطای داخلی" } });
  }
}
