import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { DomainError } from "./domain";
import * as domain from "./domain";
import * as phone from "./phone";

async function guard<T>(fn: () => Promise<T>) {
  try {
    const data = await fn();
    return { ok: true as const, data };
  } catch (err) {
    if (err instanceof DomainError) {
      return { ok: false as const, error: err.message, code: err.code };
    }
    const message = err instanceof Error ? err.message : "";
    if (message === "Unauthorized") {
      return { ok: false as const, error: "برای ادامه وارد شوید", code: "UNAUTHORIZED" };
    }
    console.error("[nobat]", err instanceof Error ? err.name : "error");
    return { ok: false as const, error: "خطای داخلی. دوباره تلاش کنید.", code: "INTERNAL" };
  }
}

export const categoriesFn = createServerFn({ method: "GET" }).handler(async () =>
  guard(() => domain.listCategories()),
);

export const businessesFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .handler(async ({ data }) => guard(() => domain.listBusinesses(data)));

export const publicBusinessFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .handler(async ({ data }) => guard(() => domain.publicBusiness(String((data as { slug?: string })?.slug ?? ""))));

export const availabilityFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .handler(async ({ data }) => guard(() => domain.availability(data)));

export const meFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => guard(() => domain.me(context.userId)));

export const updateProfileFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.updateProfile(context.userId, data)));

export const claimAdminFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => guard(() => domain.claimAdmin(context.userId)));

export const createBusinessFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.createBusiness(context.userId, data)));

export const createDemoFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => guard(() => domain.createDemo(context.userId)));

export const updateBusinessFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.updateBusiness(context.userId, data)));

export const deleteBusinessFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) =>
    guard(() => domain.deleteBusiness(context.userId, String((data as { businessId?: string })?.businessId ?? ""))),
  );

export const manageBusinessFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) =>
    guard(() => domain.manageBusiness(context.userId, String((data as { businessId?: string })?.businessId ?? ""))),
  );

export const saveServiceFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.saveService(context.userId, data)));

export const saveStaffFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.saveStaff(context.userId, data)));

export const saveScheduleFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.saveSchedule(context.userId, data)));

export const addHolidayFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.addHoliday(context.userId, data)));

export const removeHolidayFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.removeHoliday(context.userId, data)));

export const createBookingFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.createBooking(context.userId, data)));

export const setBookingStatusFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.setBookingStatus(context.userId, data)));

export const rescheduleBookingFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.rescheduleBooking(context.userId, data)));

export const myBookingsFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => guard(() => domain.myBookings(context.userId)));

export const businessBookingsFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.businessBookings(context.userId, data)));

export const customersFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.listCustomers(context.userId, data)));

export const saveCustomerFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.saveCustomer(context.userId, data)));

export const dashboardFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.dashboard(context.userId, data)));

export const notificationsFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => guard(() => domain.myNotifications(context.userId)));

export const markReadFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.markNotificationRead(context.userId, data)));

export const adminOverviewFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => guard(() => domain.adminOverview(context.userId)));

export const adminUsersFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.adminUsers(context.userId, data)));

export const adminBusinessesFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.adminBusinesses(context.userId, data)));

export const moderateBusinessFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.setBusinessModeration(context.userId, data)));

export const adminCategoriesFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => guard(() => domain.adminCategories(context.userId)));

export const saveCategoryFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.saveCategory(context.userId, data)));

export const adminAuditFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => guard(() => domain.adminAudit(context.userId)));

export const saveSettingsFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => input)
  .handler(async ({ data, context }) => guard(() => domain.saveSettings(context.userId, data)));

export const lookupPhoneFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .handler(async ({ data }) => guard(() => phone.lookupPhone(data)));

export const sendPhoneCodeFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .handler(async ({ data }) => guard(() => phone.sendPhoneCode(data)));

export const signInPhoneFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .handler(async ({ data }) => guard(() => phone.signInWithPassword(data)));

export const signInPhoneCodeFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .handler(async ({ data }) => guard(() => phone.signInWithCode(data)));

export const resetPhonePasswordFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .handler(async ({ data }) => guard(() => phone.resetPasswordWithCode(data)));

export const startAccountFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .handler(async ({ data }) => guard(() => phone.startAccount(data)));
