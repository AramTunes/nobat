import { Link } from "@tanstack/react-router";
import { Bell, CalendarClock } from "lucide-react";
import type { ReactNode } from "react";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

const links = [
  { to: "/explore", label: "کسب‌وکارها" },
  { to: "/me", label: "نوبت‌های من" },
  { to: "/panel", label: "پنل کسب‌وکار" },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  return (
    <div className="min-h-dvh">
      <header className="sticky top-0 z-20 border-b border-line bg-paper/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link to="/" className="flex items-center gap-2 font-extrabold tracking-tight">
            <span className="grid size-9 place-items-center rounded-xl bg-jade text-on-jade">
              <CalendarClock className="size-5" aria-hidden="true" />
            </span>
            نوبتک
          </Link>
          <nav className="flex flex-1 items-center gap-1 overflow-x-auto text-sm">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="shrink-0 rounded-lg px-3 py-2 text-muted hover:bg-card hover:text-ink"
                activeProps={{ className: "shrink-0 rounded-lg bg-card px-3 py-2 font-semibold text-ink" }}
              >
                {link.label}
              </Link>
            ))}
            {!isPending && user ? (
              <Link
                to="/admin"
                className="shrink-0 rounded-lg px-3 py-2 text-muted hover:bg-card hover:text-ink"
                activeProps={{ className: "shrink-0 rounded-lg bg-card px-3 py-2 font-semibold text-ink" }}
              >
                مدیریت
              </Link>
            ) : null}
          </nav>
          <div className="flex items-center gap-2">
            {isPending ? <span className="size-8 animate-pulse rounded-full bg-paper-deep" /> : null}
            {!isPending && user ? (
              <>
                <Link to="/me" aria-label="اعلان‌ها" className="grid size-11 place-items-center rounded-xl hover:bg-card">
                  <Bell className="size-5" />
                </Link>
                <UserButton />
              </>
            ) : null}
            {!isPending && !user ? (
              <>
                <Link to="/start" className="inline-flex min-h-11 shrink-0 items-center rounded-xl border border-line bg-card px-3 text-sm font-semibold">
                  شروع رایگان
                </Link>
                <Link to="/auth" search={{ next: "/" }} className="inline-flex min-h-11 shrink-0 items-center rounded-xl bg-ink px-4 text-sm font-semibold text-on-ink">
                  ورود
                </Link>
              </>
            ) : null}
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl px-4 py-6">{children}</main>
    </div>
  );
}

export function Subnav({
  items,
}: {
  items: { to: string; label: string; exact?: boolean }[];
}) {
  return (
    <div className="mb-5 flex gap-2 overflow-x-auto pb-1">
      {items.map((item) => (
        <Link
          key={item.to + item.label}
          to={item.to}
          activeOptions={{ exact: Boolean(item.exact) }}
          className="shrink-0 rounded-full border border-line bg-card px-4 py-2 text-sm"
          activeProps={{ className: "shrink-0 rounded-full bg-jade px-4 py-2 text-sm font-semibold text-on-jade" }}
        >
          {item.label}
        </Link>
      ))}
    </div>
  );
}
