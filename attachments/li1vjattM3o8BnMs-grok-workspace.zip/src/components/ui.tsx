import { cn } from "@/lib/cn";
import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";

export function Button({
  variant = "primary",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "quiet" | "danger" | "ink" }) {
  const styles = {
    primary: "bg-jade text-on-jade hover:bg-jade-deep",
    quiet: "bg-card text-ink border border-line hover:bg-paper",
    danger: "bg-danger-soft text-danger hover:bg-danger hover:text-on-ink",
    ink: "bg-ink text-on-ink hover:bg-jade-deep",
  }[variant];
  return (
    <button
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition disabled:opacity-50",
        styles,
        className,
      )}
      {...props}
    />
  );
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <section className={cn("rounded-card border border-line bg-card p-5 shadow-sm", className)}>{children}</section>;
}

export function Badge({
  tone = "jade",
  children,
}: {
  tone?: "jade" | "copper" | "muted" | "danger";
  children: ReactNode;
}) {
  const styles = {
    jade: "bg-jade-soft text-jade-deep",
    copper: "bg-copper-soft text-copper",
    muted: "bg-paper-deep text-muted",
    danger: "bg-danger-soft text-danger",
  }[tone];
  return <span className={cn("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold", styles)}>{children}</span>;
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="grid gap-1.5 text-sm">
      <span className="font-medium">{label}</span>
      {children}
      {hint ? <span className="text-xs text-muted">{hint}</span> : null}
    </label>
  );
}

export function TextInput(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={cn(
        "min-h-11 w-full rounded-xl border border-line bg-card px-3 text-sm outline-none",
        props.className,
      )}
    />
  );
}

export function Area(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={cn(
        "min-h-24 w-full rounded-xl border border-line bg-card px-3 py-2 text-sm outline-none",
        props.className,
      )}
    />
  );
}

export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={cn(
        "min-h-11 w-full rounded-xl border border-line bg-card px-3 text-sm outline-none",
        props.className,
      )}
    />
  );
}

export function Empty({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return (
    <div className="grid justify-items-center gap-3 rounded-card border border-dashed border-line bg-card px-6 py-12 text-center">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="max-w-md text-sm text-muted">{body}</p>
      {action}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("animate-pulse rounded-xl bg-paper-deep", className)} />;
}

export function ErrorNote({ children }: { children: ReactNode }) {
  return <p className="rounded-xl bg-danger-soft px-3 py-2 text-sm text-danger">{children}</p>;
}
