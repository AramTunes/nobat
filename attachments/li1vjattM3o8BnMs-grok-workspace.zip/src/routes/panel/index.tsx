import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { usePanel } from "@/components/account";
import { Button, Card, Empty, Field, Skeleton, TextInput } from "@/components/ui";
import { faNum } from "@/lib/booking/fa";
import { categoriesFn, createBusinessFn, createDemoFn, dashboardFn } from "@/server/fns";

export const Route = createFileRoute("/panel/")({ component: PanelHome });

function PanelHome() {
  const { businessId } = usePanel();
  const [categories, setCategories] = useState<{ id: string; name: string }[]>([]);
  const [form, setForm] = useState({ name: "", city: "", phone: "", categoryId: "cat-beauty" });
  const [dash, setDash] = useState<{
    today: number;
    byStatus: Record<string, number>;
    capacity: { availableMinutes: number; occupiedMinutes: number; freeMinutes: number; formula: string };
  } | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    categoriesFn().then((res) => {
      if (res.ok) setCategories(res.data);
    });
  }, []);
  useEffect(() => {
    if (!businessId) return;
    let live = true;
    setLoading(true);
    dashboardFn({ data: { businessId } }).then((res) => {
      if (!live) return;
      setDash(res.ok ? res.data : null);
      if (!res.ok) toast.error(res.error);
      setLoading(false);
    });
    return () => {
      live = false;
    };
  }, [businessId]);

  if (!businessId) {
    return (
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <h2 className="text-xl font-bold">کسب‌وکار تازه</h2>
          <form className="mt-4 grid gap-3" onSubmit={async (event) => {
            event.preventDefault();
            const res = await createBusinessFn({ data: { ...form, timezone: "Asia/Tehran" } });
            if (!res.ok) { toast.error(res.error); return; }
            localStorage.setItem("nobatak.business", res.data.businessId);
            toast.success("ساخته شد");
            window.location.assign("/panel/services");
          }}>
            <Field label="نام"><TextInput value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></Field>
            <Field label="شهر"><TextInput value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></Field>
            <Field label="تلفن"><TextInput dir="ltr" className="text-left" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
            <Field label="دسته">
              <select className="min-h-11 rounded-xl border border-line bg-card px-3" value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })}>
                {categories.map((cat) => <option key={cat.id} value={cat.id}>{cat.name}</option>)}
              </select>
            </Field>
            <Button type="submit">ساخت کسب‌وکار</Button>
          </form>
        </Card>
        <Card>
          <h2 className="text-xl font-bold">نمونه قابل حذف</h2>
          <p className="mt-2 text-sm leading-6 text-muted">یک آرایشگاه با خدمت، همکار و ساعت کاری می‌سازد تا رزرو را امتحان کنید. برچسب نمونه روی صفحه عمومی می‌ماند.</p>
          <Button className="mt-4" variant="quiet" onClick={async () => {
            const res = await createDemoFn();
            if (!res.ok) { toast.error(res.error); return; }
            localStorage.setItem("nobatak.business", res.data.businessId);
            window.location.assign("/panel");
          }}>ساخت نمونه</Button>
        </Card>
      </div>
    );
  }
  if (loading || !dash) return <Skeleton className="h-40" />;
  const total = Object.values(dash.byStatus).reduce((sum, n) => sum + n, 0);
  return (
    <div className="grid gap-3">
      <div className="grid gap-3 sm:grid-cols-4">
        {[
          ["امروز", dash.today],
          ["بازه ۷ روز", total],
          ["انجام‌شده", dash.byStatus.completed ?? 0],
          ["لغوشده", dash.byStatus.cancelled ?? 0],
        ].map(([label, value]) => (
          <Card key={String(label)}>
            <div className="text-sm text-muted">{label}</div>
            <div className="mt-1 text-3xl font-extrabold tabular-nums">{faNum(Number(value))}</div>
          </Card>
        ))}
      </div>
      <Card>
        <h2 className="font-bold">ظرفیت هفت روز آینده</h2>
        <p className="mt-2 text-sm leading-6 text-muted">{dash.capacity.formula}</p>
        <div className="mt-4 grid gap-2 text-sm sm:grid-cols-3">
          <div>قابل عرضه: {faNum(dash.capacity.availableMinutes)} دقیقه</div>
          <div>اشغال‌شده: {faNum(dash.capacity.occupiedMinutes)} دقیقه</div>
          <div>آزاد: {faNum(dash.capacity.freeMinutes)} دقیقه</div>
        </div>
        <div className="mt-3 h-3 overflow-hidden rounded-full bg-paper-deep">
          <div className="h-full bg-jade" style={{ width: `${dash.capacity.availableMinutes ? Math.min(100, (dash.capacity.occupiedMinutes / dash.capacity.availableMinutes) * 100) : 0}%` }} />
        </div>
        <Link to="/panel/calendar" className="mt-4 inline-flex text-sm font-semibold text-jade">تقویم نوبت‌ها</Link>
      </Card>
    </div>
  );
}
