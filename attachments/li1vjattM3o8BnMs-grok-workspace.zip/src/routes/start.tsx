import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "@/components/shell";
import { Button, Card, ErrorNote, Field, TextInput } from "@/components/ui";
import { adoptSession } from "@/lib/auth/client";
import { categoriesFn, sendPhoneCodeFn, startAccountFn } from "@/server/fns";

export const Route = createFileRoute("/start")({
  component: StartPage,
});

const STEPS = ["حوزه فعالیت", "این صفحه برای کیست", "اسم صفحه", "نام کاربری", "شماره موبایل", "کد تأیید"];

function StartPage() {
  const [categories, setCategories] = useState<{ id: string; name: string }[]>([]);
  const [step, setStep] = useState(0);
  const [categoryId, setCategoryId] = useState("");
  const [pageFor, setPageFor] = useState<"self" | "business" | "">("");
  const [pageName, setPageName] = useState("");
  const [username, setUsername] = useState("");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [shownCode, setShownCode] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  useEffect(() => {
    categoriesFn().then((res) => {
      if (res.ok) setCategories(res.data);
    });
  }, []);

  function next() {
    setError("");
    if (step === 0 && !categoryId) return setError("حوزه فعالیت را انتخاب کنید");
    if (step === 1 && !pageFor) return setError("یکی را انتخاب کنید");
    if (step === 2 && pageName.trim().length < 2) return setError("اسم صفحه را بنویسید");
    if (step === 3 && !/^[\p{L}\p{N}_]{3,24}$/u.test(username.trim())) {
      return setError("نام کاربری باید ۳ تا ۲۴ حرف، عدد یا _ باشد");
    }
    setStep((n) => Math.min(n + 1, STEPS.length - 1));
  }

  async function requestCode(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setPending(true);
    const res = await sendPhoneCodeFn({ data: { phone, purpose: "signup" } });
    setPending(false);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    setShownCode(res.data.code);
    setCode("");
    setStep(5);
  }

  async function finish(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setPending(true);
    const res = await startAccountFn({
      data: { categoryId, pageFor, pageName: pageName.trim(), username: username.trim(), phone, code: code.trim() },
    });
    setPending(false);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    await adoptSession(res.data.token);
    window.location.assign("/panel");
  }

  return (
    <Shell>
      <div className="mx-auto grid max-w-lg gap-4">
        <p className="text-sm text-muted">گام {step + 1} از {STEPS.length}</p>
        <div className="h-1.5 overflow-hidden rounded-full bg-paper-deep">
          <div className="h-full bg-jade" style={{ width: `${((step + 1) / STEPS.length) * 100}%` }} />
        </div>
        <h1 className="text-3xl font-extrabold">{STEPS[step]}</h1>
        <Card>
          {step === 0 ? (
            <div className="grid gap-2 sm:grid-cols-2">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  className={categoryId === cat.id ? "min-h-11 rounded-xl bg-jade px-3 text-sm font-semibold text-on-jade" : "min-h-11 rounded-xl border border-line bg-card px-3 text-sm"}
                  onClick={() => setCategoryId(cat.id)}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          ) : null}
          {step === 1 ? (
            <div className="grid gap-3">
              <Choice on={pageFor === "self"} onClick={() => setPageFor("self")} title="برای خودم" text="صفحه با اسم خودتان ساخته می‌شود." />
              <Choice on={pageFor === "business"} onClick={() => setPageFor("business")} title="برای کسب‌وکارم" text="صفحه با اسم کسب‌وکار ساخته می‌شود." />
            </div>
          ) : null}
          {step === 2 ? (
            <Field label={pageFor === "business" ? "اسم کسب‌وکار" : "اسم شما"} hint="همین اسم روی صفحه دیده می‌شود">
              <TextInput value={pageName} onChange={(e) => setPageName(e.target.value)} minLength={2} autoComplete="organization" />
            </Field>
          ) : null}
          {step === 3 ? (
            <Field label="نام کاربری" hint="۳ تا ۲۴ حرف، عدد یا _">
              <TextInput dir="ltr" className="text-left" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" />
            </Field>
          ) : null}
          {step === 4 ? (
            <form className="grid gap-3" onSubmit={requestCode}>
              <Field label="شماره موبایل" hint="کد تأیید برای همین شماره فرستاده می‌شود">
                <TextInput dir="ltr" className="text-left" inputMode="tel" autoComplete="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required />
              </Field>
              {error ? <ErrorNote>{error}</ErrorNote> : null}
              <div className="flex gap-2">
                <Button type="button" variant="quiet" onClick={() => { setError(""); setStep(3); }}>قبلی</Button>
                <Button type="submit" disabled={pending}>{pending ? "در حال ارسال" : "دریافت کد"}</Button>
              </div>
            </form>
          ) : null}
          {step === 5 ? (
            <form className="grid gap-3" onSubmit={finish}>
              {shownCode ? (
                <p className="rounded-xl bg-paper-deep px-3 py-2 text-sm leading-6">
                  پیامک وصل نیست. کد تأیید: <span className="font-bold" dir="ltr">{shownCode}</span>
                </p>
              ) : null}
              <Field label="کد تأیید">
                <TextInput dir="ltr" className="text-left tracking-widest" inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} required />
              </Field>
              {error ? <ErrorNote>{error}</ErrorNote> : null}
              <div className="flex gap-2">
                <Button type="button" variant="quiet" onClick={() => { setError(""); setStep(4); }}>قبلی</Button>
                <Button type="submit" disabled={pending || code.trim().length < 6}>{pending ? "در حال ساخت" : "ساخت حساب"}</Button>
              </div>
            </form>
          ) : null}
          {step < 4 ? (
            <div className="mt-4 grid gap-3">
              {error ? <ErrorNote>{error}</ErrorNote> : null}
              <div className="flex gap-2">
                {step > 0 ? <Button type="button" variant="quiet" onClick={() => { setError(""); setStep((n) => n - 1); }}>قبلی</Button> : null}
                <Button type="button" onClick={next}>بعدی</Button>
              </div>
            </div>
          ) : null}
        </Card>
      </div>
    </Shell>
  );
}

function Choice({ on, onClick, title, text }: { on: boolean; onClick: () => void; title: string; text: string }) {
  return (
    <button type="button" onClick={onClick} className={on ? "rounded-xl bg-jade px-4 py-4 text-start text-on-jade" : "rounded-xl border border-line px-4 py-4 text-start"}>
      <div className="font-bold">{title}</div>
      <p className={on ? "mt-1 text-sm" : "mt-1 text-sm text-muted"}>{text}</p>
    </button>
  );
}
