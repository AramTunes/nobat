import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { PGlite } from "@electric-sql/pglite";
import { insertBookingIfFree, type Queryable } from "./reserve.ts";

const SCHEMA = `
  create table staff (
    id text primary key,
    business_id text not null,
    active boolean not null default true
  );
  create table bookings (
    id text primary key,
    business_id text not null,
    branch_id text not null,
    service_id text not null,
    staff_id text not null,
    customer_id text not null,
    customer_user_id text,
    created_by_user_id text not null,
    starts_at timestamptz not null,
    ends_at timestamptz not null,
    buffer_until timestamptz not null,
    status text not null,
    source text not null,
    idempotency_key text,
    note text not null default ''
  );
`;

function row(id: string, start: string, end: string, bufferUntil = end) {
  return {
    id,
    businessId: "b1",
    branchId: "br1",
    serviceId: "sv1",
    staffId: "st1",
    customerId: "c1",
    customerUserId: null,
    createdByUserId: "u1",
    startsAt: start,
    endsAt: end,
    bufferUntil,
    status: "confirmed" as const,
    source: "online" as const,
    idempotencyKey: id,
    note: "",
  };
}

describe("reserve lock", () => {
  it("rejects a second overlapping booking and allows the next free slot", async () => {
    const pg = new PGlite();
    await pg.waitReady;
    await pg.exec(SCHEMA);
    await pg.exec(`insert into staff (id, business_id) values ('st1', 'b1')`);
    const q = (tx: { query: PGlite["query"] }): Queryable => ({
      query: async (text, params) => (await tx.query(text, params)).rows as never,
    });
    const first = await pg.transaction((tx) =>
      insertBookingIfFree(
        q(tx),
        row("bk1", "2026-10-22T06:00:00.000Z", "2026-10-22T07:00:00.000Z", "2026-10-22T07:15:00.000Z"),
      ),
    );
    const overlap = await pg.transaction((tx) =>
      insertBookingIfFree(
        q(tx),
        row("bk2", "2026-10-22T06:30:00.000Z", "2026-10-22T07:00:00.000Z"),
      ),
    );
    const backToBack = await pg.transaction((tx) =>
      insertBookingIfFree(
        q(tx),
        row("bk3", "2026-10-22T07:15:00.000Z", "2026-10-22T08:00:00.000Z"),
      ),
    );
    assert.equal(first, "ok");
    assert.equal(overlap, "conflict");
    assert.equal(backToBack, "ok");
    const left = await pg.query<{ id: string }>(`select id from bookings order by starts_at`);
    assert.deepEqual(
      left.rows.map((r) => r.id),
      ["bk1", "bk3"],
    );
  });

  it("serializes two concurrent inserts for the same slot", async () => {
    const pg = new PGlite();
    await pg.waitReady;
    await pg.exec(SCHEMA);
    await pg.exec(`insert into staff (id, business_id) values ('st1', 'b1')`);
    const attempt = (id: string) =>
      pg.transaction(async (tx) => {
        const q: Queryable = {
          query: async (text, params) => (await tx.query(text, params)).rows as never,
        };
        return insertBookingIfFree(
          q,
          row(id, "2026-10-22T09:00:00.000Z", "2026-10-22T10:00:00.000Z"),
        );
      });
    const [a, b] = await Promise.all([attempt("a"), attempt("b")]);
    const wins = [a, b].filter((r) => r === "ok");
    assert.equal(wins.length, 1);
    const left = await pg.query(`select id from bookings`);
    assert.equal(left.rows.length, 1);
  });
});
