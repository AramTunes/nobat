import { clipDay, type Span } from "./slots.ts";
import { addDaysYmd, civilInZone, minutesFromLocalMidnight, todayYmd, zonedCivilToUtc } from "./time.ts";

export type BusyInterval = { startsAt: string; bufferUntil: string };

export type StaffCalendar = {
  staffId: string;
  windows: Span[];
  breaks: Span[];
  busy: BusyInterval[];
  holiday: boolean;
};

export type SlotOption = { start: string; staffIds: string[] };

function wallToUtc(day: string, minuteOfDay: number, timeZone: string): Date | null {
  const dayOffset = Math.floor(minuteOfDay / 1440);
  const minute = minuteOfDay - dayOffset * 1440;
  const dateDay = dayOffset === 0 ? day : addDaysYmd(day, dayOffset, timeZone);
  const [y, m, d] = dateDay.split("-").map(Number);
  const hour = Math.floor(minute / 60);
  const min = minute % 60;
  const utc = zonedCivilToUtc({ year: y, month: m, day: d, hour, minute: min }, timeZone);
  const got = civilInZone(utc, timeZone);
  if (got.year !== y || got.month !== m || got.day !== d || got.hour !== hour || got.minute !== min) {
    return null;
  }
  return utc;
}

function overlaps(startMs: number, endMs: number, otherStart: number, otherEnd: number): boolean {
  return startMs < otherEnd && otherStart < endMs;
}

/**
 * Real instants a service can start.
 * Stepping is in UTC milliseconds so a DST gap is not treated as bookable time
 * and a one-hour service always occupies sixty real minutes.
 * Windows do not wrap past local midnight (end minute 1440 is the next local midnight).
 */
export function slotsForStaff(opts: {
  day: string;
  timeZone: string;
  windows: Span[];
  breaks: Span[];
  busy: BusyInterval[];
  durationMin: number;
  bufferMin: number;
  stepMin: number;
  earliestUtc?: Date;
}): Date[] {
  if (opts.durationMin <= 0 || opts.stepMin <= 0) return [];
  const step = opts.stepMin * 60_000;
  const need = (opts.durationMin + Math.max(0, opts.bufferMin)) * 60_000;
  const breaksUtc: { start: number; end: number }[] = [];
  for (const br of opts.breaks) {
    const s = wallToUtc(opts.day, br.start, opts.timeZone);
    const e = wallToUtc(opts.day, br.end, opts.timeZone);
    if (s && e && e.getTime() > s.getTime()) breaksUtc.push({ start: s.getTime(), end: e.getTime() });
  }
  const busyUtc = opts.busy.map((b) => ({
    start: new Date(b.startsAt).getTime(),
    end: new Date(b.bufferUntil).getTime(),
  }));
  const earliest = opts.earliestUtc?.getTime() ?? Number.NEGATIVE_INFINITY;
  const out: Date[] = [];
  for (const window of opts.windows) {
    const ws = wallToUtc(opts.day, window.start, opts.timeZone);
    const we = wallToUtc(opts.day, window.end, opts.timeZone);
    if (!ws || !we || we.getTime() <= ws.getTime()) continue;
    let t = ws.getTime();
    if (earliest > t) {
      const jumps = Math.ceil((earliest - t) / step);
      t += jumps * step;
    }
    while (t + need <= we.getTime()) {
      const end = t + need;
      const blocked =
        breaksUtc.some((b) => overlaps(t, end, b.start, b.end)) ||
        busyUtc.some((b) => overlaps(t, end, b.start, b.end));
      if (!blocked) out.push(new Date(t));
      t += step;
    }
  }
  return out;
}

export function dayAvailability(opts: {
  day: string;
  timeZone: string;
  now: Date;
  durationMin: number;
  bufferMin: number;
  stepMin: number;
  minLeadMinutes: number;
  maxHorizonDays: number;
  staff: StaffCalendar[];
}): SlotOption[] {
  const today = todayYmd(opts.timeZone, opts.now);
  const horizon = addDaysYmd(today, opts.maxHorizonDays, opts.timeZone);
  if (opts.day < today || opts.day > horizon) return [];
  const earliest =
    opts.day === today ? new Date(opts.now.getTime() + opts.minLeadMinutes * 60_000) : undefined;
  const grouped = new Map<string, string[]>();
  for (const member of opts.staff) {
    if (member.holiday) continue;
    const instants = slotsForStaff({
      day: opts.day,
      timeZone: opts.timeZone,
      windows: member.windows,
      breaks: member.breaks,
      busy: member.busy,
      durationMin: opts.durationMin,
      bufferMin: opts.bufferMin,
      stepMin: opts.stepMin,
      earliestUtc: earliest,
    });
    for (const instant of instants) {
      const key = instant.toISOString();
      const list = grouped.get(key);
      if (list) list.push(member.staffId);
      else grouped.set(key, [member.staffId]);
    }
  }
  return [...grouped.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([start, staffIds]) => ({ start, staffIds }));
}

/** Local-minute occupancy of bookings that touch `day`, for capacity reports. */
export function occupiedMinutesOnDay(
  busy: BusyInterval[],
  day: string,
  timeZone: string,
): number {
  let total = 0;
  for (const item of busy) {
    const start = minutesFromLocalMidnight(new Date(item.startsAt), day, timeZone);
    const end = minutesFromLocalMidnight(new Date(item.bufferUntil), day, timeZone);
    const clipped = clipDay(start, end);
    if (clipped) total += clipped.end - clipped.start;
  }
  return total;
}
