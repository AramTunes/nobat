/** Transactional staff lock + overlap check. Caller must already be inside a transaction. */

export type Queryable = {
  query<T = Record<string, unknown>>(text: string, params?: unknown[]): Promise<T[]>;
};

export type NewBookingRow = {
  id: string;
  businessId: string;
  branchId: string;
  serviceId: string;
  staffId: string;
  customerId: string;
  customerUserId: string | null;
  createdByUserId: string;
  startsAt: string;
  endsAt: string;
  bufferUntil: string;
  status: "confirmed" | "pending";
  source: "online" | "manual";
  idempotencyKey: string | null;
  note: string;
};

const CLASH_SQL = `
  select id from bookings
  where staff_id = $1
    and status in ('confirmed', 'pending')
    and starts_at < $2::timestamptz
    and buffer_until > $3::timestamptz
    and ($4::text is null or id <> $4)
  for update
`;

export async function insertBookingIfFree(
  db: Queryable,
  row: NewBookingRow,
): Promise<"ok" | "conflict" | "missing_staff"> {
  const staff = await db.query<{ id: string }>(
    `select id from staff where id = $1 and business_id = $2 and active = true for update`,
    [row.staffId, row.businessId],
  );
  if (!staff.length) return "missing_staff";
  const clash = await db.query<{ id: string }>(CLASH_SQL, [
    row.staffId,
    row.bufferUntil,
    row.startsAt,
    null,
  ]);
  if (clash.length) return "conflict";
  await db.query(
    `insert into bookings (
      id, business_id, branch_id, service_id, staff_id, customer_id, customer_user_id,
      created_by_user_id, starts_at, ends_at, buffer_until, status, source, idempotency_key, note
    ) values (
      $1,$2,$3,$4,$5,$6,$7,$8,$9::timestamptz,$10::timestamptz,$11::timestamptz,$12,$13,$14,$15
    )`,
    [
      row.id,
      row.businessId,
      row.branchId,
      row.serviceId,
      row.staffId,
      row.customerId,
      row.customerUserId,
      row.createdByUserId,
      row.startsAt,
      row.endsAt,
      row.bufferUntil,
      row.status,
      row.source,
      row.idempotencyKey,
      row.note,
    ],
  );
  return "ok";
}

export async function moveBookingIfFree(
  db: Queryable,
  input: {
    bookingId: string;
    businessId: string;
    staffId: string;
    startsAt: string;
    endsAt: string;
    bufferUntil: string;
    serviceId: string;
    branchId: string;
  },
): Promise<"ok" | "conflict" | "missing"> {
  const staff = await db.query<{ id: string }>(
    `select id from staff where id = $1 and business_id = $2 and active = true for update`,
    [input.staffId, input.businessId],
  );
  if (!staff.length) return "missing";
  const clash = await db.query<{ id: string }>(CLASH_SQL, [
    input.staffId,
    input.bufferUntil,
    input.startsAt,
    input.bookingId,
  ]);
  if (clash.length) return "conflict";
  const updated = await db.query<{ id: string }>(
    `update bookings
     set staff_id = $1, starts_at = $2::timestamptz, ends_at = $3::timestamptz,
         buffer_until = $4::timestamptz, service_id = $5, branch_id = $6, updated_at = now()
     where id = $7 and business_id = $8
       and status in ('confirmed', 'pending')
     returning id`,
    [
      input.staffId,
      input.startsAt,
      input.endsAt,
      input.bufferUntil,
      input.serviceId,
      input.branchId,
      input.bookingId,
      input.businessId,
    ],
  );
  return updated.length ? "ok" : "missing";
}
