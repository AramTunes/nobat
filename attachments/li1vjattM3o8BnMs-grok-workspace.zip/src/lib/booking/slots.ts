/** Half-open minute spans from local midnight: [start, end). */

export type Span = { start: number; end: number };

export function rangesOverlap(a0: number, a1: number, b0: number, b1: number): boolean {
  return a0 < b1 && b0 < a1;
}

function clean(span: Span): Span | null {
  if (span.end <= span.start) return null;
  return span;
}

/** Remove `cuts` from `base`. Spans that cross a cut are split. */
export function subtractSpans(base: Span[], cuts: Span[]): Span[] {
  let parts = base.map(clean).filter((s): s is Span => s !== null);
  for (const raw of cuts) {
    const cut = clean(raw);
    if (!cut) continue;
    const next: Span[] = [];
    for (const part of parts) {
      if (cut.end <= part.start || cut.start >= part.end) {
        next.push(part);
        continue;
      }
      if (cut.start > part.start) next.push({ start: part.start, end: cut.start });
      if (cut.end < part.end) next.push({ start: cut.end, end: part.end });
    }
    parts = next;
  }
  return parts;
}

export type SlotInput = {
  windows: Span[];
  breaks: Span[];
  /** Existing occupancy, including preparation buffer. May extend outside 0..1440. */
  busy: Span[];
  durationMin: number;
  bufferMin: number;
  stepMin: number;
  /** Local minute before which a slot may not start (lead time). */
  earliestStart?: number;
};

/**
 * Start minutes of bookable slots.
 * The whole service duration plus buffer must sit inside one free window,
 * so a slot cannot cross a break, a booking, or the end of working hours
 * (including past midnight — windows themselves do not wrap past 24:00).
 */
export function slotStarts(input: SlotInput): number[] {
  if (input.durationMin <= 0 || input.stepMin <= 0) return [];
  const open = subtractSpans(input.windows, [...input.breaks, ...input.busy]);
  const need = input.durationMin + Math.max(0, input.bufferMin);
  const starts: number[] = [];
  for (const window of open) {
    let t = window.start;
    if (input.earliestStart != null && t < input.earliestStart) t = input.earliestStart;
    const rem = ((t % input.stepMin) + input.stepMin) % input.stepMin;
    if (rem !== 0) t += input.stepMin - rem;
    while (t + need <= window.end) {
      starts.push(t);
      t += input.stepMin;
    }
  }
  return starts;
}

export function clipDay(start: number, end: number): Span | null {
  const s = Math.max(0, start);
  const e = Math.min(24 * 60, end);
  if (e <= s) return null;
  return { start: s, end: e };
}
