import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { dayAvailability, slotsForStaff } from "./availability.ts";
import { gregorianToJalali } from "./jalali.ts";
import { slotStarts, subtractSpans } from "./slots.ts";
import { civilInZone, zonedCivilToUtc } from "./time.ts";

const TEHRAN = "Asia/Tehran";

describe("slot arithmetic", () => {
  it("splits a window around a break and a booking", () => {
    const open = subtractSpans(
      [{ start: 9 * 60, end: 18 * 60 }],
      [
        { start: 13 * 60, end: 14 * 60 },
        { start: 10 * 60, end: 11 * 60 },
      ],
    );
    assert.deepEqual(open, [
      { start: 9 * 60, end: 10 * 60 },
      { start: 11 * 60, end: 13 * 60 },
      { start: 14 * 60, end: 18 * 60 },
    ]);
  });

  it("does not place a service across a break or past closing", () => {
    const starts = slotStarts({
      windows: [{ start: 9 * 60, end: 13 * 60 }],
      breaks: [{ start: 12 * 60, end: 12 * 60 + 30 }],
      busy: [],
      durationMin: 60,
      bufferMin: 0,
      stepMin: 30,
    });
    assert.deepEqual(starts, [9 * 60, 9 * 60 + 30, 10 * 60, 10 * 60 + 30, 11 * 60]);
    assert.equal(starts.includes(11 * 60 + 30), false);
  });

  it("keeps preparation buffer inside the free window", () => {
    const starts = slotStarts({
      windows: [{ start: 9 * 60, end: 11 * 60 }],
      breaks: [],
      busy: [],
      durationMin: 60,
      bufferMin: 15,
      stepMin: 15,
    });
    assert.deepEqual(starts, [9 * 60, 9 * 60 + 15, 9 * 60 + 30, 9 * 60 + 45]);
  });
});

describe("timezone and calendar edges", () => {
  it("round-trips Tehran wall time, including across local midnight", () => {
    const morning = zonedCivilToUtc({ year: 2026, month: 10, day: 22, hour: 0, minute: 30 }, TEHRAN);
    const night = zonedCivilToUtc({ year: 2026, month: 10, day: 22, hour: 23, minute: 30 }, TEHRAN);
    assert.equal(morning.toISOString(), "2026-10-21T21:00:00.000Z");
    assert.equal(night.toISOString(), "2026-10-22T20:00:00.000Z");
    assert.equal(civilInZone(morning, TEHRAN).day, 22);
    assert.equal(civilInZone(night, TEHRAN).hour, 23);
    assert.notEqual(morning.toISOString().slice(0, 10), night.toISOString().slice(0, 10));
  });

  it("maps Nowruz 2026 to 1405/1/1", () => {
    assert.deepEqual(gregorianToJalali(2026, 3, 21), { jy: 1405, jm: 1, jd: 1 });
  });

  it("rejects a slot that would run past local midnight", () => {
    const slots = slotsForStaff({
      day: "2026-10-22",
      timeZone: TEHRAN,
      windows: [{ start: 22 * 60, end: 24 * 60 }],
      breaks: [],
      busy: [],
      durationMin: 60,
      bufferMin: 0,
      stepMin: 30,
    });
    const labels = slots.map((d) => civilInZone(d, TEHRAN).hour + ":" + civilInZone(d, TEHRAN).minute);
    assert.deepEqual(labels, ["22:0", "22:30", "23:0"]);
  });

  it("lets a booking that crossed midnight block the next morning", () => {
    const slots = slotsForStaff({
      day: "2026-10-22",
      timeZone: TEHRAN,
      windows: [{ start: 0, end: 3 * 60 }],
      breaks: [],
      busy: [
        {
          startsAt: "2026-10-21T20:00:00.000Z",
          bufferUntil: "2026-10-21T21:00:00.000Z",
        },
      ],
      durationMin: 30,
      bufferMin: 0,
      stepMin: 30,
    });
    const minutes = slots.map((d) => civilInZone(d, TEHRAN).minute + civilInZone(d, TEHRAN).hour * 60);
    assert.deepEqual(minutes, [30, 60, 90, 120, 150]);
  });

  it("drops the missing hour on a US spring-forward day and stays monotonic", () => {
    const slots = slotsForStaff({
      day: "2026-03-08",
      timeZone: "America/New_York",
      windows: [{ start: 60, end: 4 * 60 }],
      breaks: [],
      busy: [],
      durationMin: 30,
      bufferMin: 0,
      stepMin: 30,
    });
    const hours = slots.map((d) => civilInZone(d, "America/New_York").hour);
    assert.equal(hours.includes(2), false);
    assert.ok(hours.includes(1));
    assert.ok(hours.includes(3));
    for (let i = 1; i < slots.length; i += 1) {
      assert.ok(slots[i].getTime() > slots[i - 1].getTime());
    }
  });

  it("does not throw on a fall-back day and keeps instants increasing", () => {
    const slots = slotsForStaff({
      day: "2026-11-01",
      timeZone: "America/New_York",
      windows: [{ start: 0, end: 3 * 60 }],
      breaks: [],
      busy: [],
      durationMin: 30,
      bufferMin: 0,
      stepMin: 30,
    });
    assert.ok(slots.length >= 4);
    for (let i = 1; i < slots.length; i += 1) {
      assert.ok(slots[i].getTime() > slots[i - 1].getTime());
    }
  });

  it("hides today slots inside the lead time and dates past the horizon", () => {
    const now = new Date("2026-10-22T07:00:00.000Z"); // 10:30 Tehran
    const today = dayAvailability({
      day: "2026-10-22",
      timeZone: TEHRAN,
      now,
      durationMin: 30,
      bufferMin: 0,
      stepMin: 30,
      minLeadMinutes: 60,
      maxHorizonDays: 2,
      staff: [
        {
          staffId: "s1",
          windows: [{ start: 9 * 60, end: 13 * 60 }],
          breaks: [],
          busy: [],
          holiday: false,
        },
      ],
    });
    const first = civilInZone(new Date(today[0].start), TEHRAN);
    assert.equal(first.hour, 11);
    assert.equal(first.minute, 30);
    const later = dayAvailability({
      day: "2026-10-25",
      timeZone: TEHRAN,
      now,
      durationMin: 30,
      bufferMin: 0,
      stepMin: 30,
      minLeadMinutes: 60,
      maxHorizonDays: 2,
      staff: [
        {
          staffId: "s1",
          windows: [{ start: 9 * 60, end: 12 * 60 }],
          breaks: [],
          busy: [],
          holiday: false,
        },
      ],
    });
    assert.deepEqual(later, []);
  });

  it("gives a holiday no slots and still offers the other specialist", () => {
    const slots = dayAvailability({
      day: "2026-10-24",
      timeZone: TEHRAN,
      now: new Date("2026-10-22T08:00:00.000Z"),
      durationMin: 30,
      bufferMin: 0,
      stepMin: 60,
      minLeadMinutes: 0,
      maxHorizonDays: 14,
      staff: [
        {
          staffId: "off",
          windows: [{ start: 9 * 60, end: 12 * 60 }],
          breaks: [],
          busy: [],
          holiday: true,
        },
        {
          staffId: "on",
          windows: [{ start: 9 * 60, end: 11 * 60 }],
          breaks: [],
          busy: [],
          holiday: false,
        },
      ],
    });
    assert.ok(slots.every((s) => s.staffIds.length === 1 && s.staffIds[0] === "on"));
    assert.equal(slots.length, 2);
  });
});
