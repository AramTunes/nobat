import { o as __toESM } from "./_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { a as MapPin, i as Phone } from "./_libs/lucide-react.mjs";
import { r as Route$1 } from "./_ssr/router-CUtJgkix.mjs";
import { a as Empty, i as Card, l as Skeleton, n as Badge } from "./_ssr/ui-CGkjkGGn.mjs";
import { i as clockLabel, o as minutesLabel, r as WEEKDAYS_FA, s as toman } from "./_ssr/fa-D0mpco5k.mjs";
import { w as publicBusinessFn } from "./_ssr/fns-CBlOdITi.mjs";
import { n as Shell } from "./_ssr/shell-B3P9KCBZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-C34Sy10m.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BusinessPage() {
	const { slug } = Route$1.useParams();
	const [biz, setBiz] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let live = true;
		publicBusinessFn({ data: { slug } }).then((res) => {
			if (!live) return;
			if (res.ok) setBiz(res.data);
			else setError(res.error);
			setLoading(false);
		});
		return () => {
			live = false;
		};
	}, [slug]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-48" }) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: "صفحه در دسترس نیست",
			body: error
		}) : null,
		biz ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-3xl font-extrabold",
								children: biz.name
							}),
							biz.isDemo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "copper",
								children: "داده نمونه"
							}) : null,
							biz.categoryName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: biz.categoryName }) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl leading-7 text-muted",
						children: biz.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 flex flex-wrap gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }),
								biz.city,
								" ",
								biz.address
							]
						}), biz.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), biz.phone]
						}) : null]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/b/$slug/book",
					params: { slug },
					className: "inline-flex min-h-11 items-center rounded-xl bg-jade px-5 font-semibold text-on-jade",
					children: "رزرو نوبت"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-[1.3fr_0.7fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3",
					children: biz.services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-bold",
							children: service.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: service.description
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold tabular-nums",
								children: toman(service.priceToman)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm text-muted",
								children: minutesLabel(service.durationMinutes)
							})]
						})]
					}) }, service.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold",
						children: "همکاران و ساعت کاری"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: ["منطقه زمانی: ", biz.timezone]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 grid gap-4",
						children: biz.staff.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-semibold",
								children: person.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm text-muted",
								children: person.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 grid gap-1 text-sm",
								children: person.weekly.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: WEEKDAYS_FA[row.weekday] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums",
										children: [
											clockLabel(row.startMin),
											" تا ",
											clockLabel(row.endMin)
										]
									})]
								}, row.weekday))
							})
						] }, person.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-xs leading-5 text-muted",
						children: [
							"لغو توسط مشتری تا ",
							biz.cancelBeforeMinutes,
							" دقیقه قبل از نوبت. رزرو از ",
							biz.minLeadMinutes,
							" دقیقه بعد تا ",
							biz.maxHorizonDays,
							" روز آینده."
						]
					})
				] })]
			})]
		}) : null
	] });
}
//#endregion
export { BusinessPage as component };
