import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as addDaysYmd, z as todayYmd } from "./domain-DOE5vDbR.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route } from "./router-CUtJgkix.mjs";
import { a as Empty, i as Card, l as Skeleton, n as Badge, o as ErrorNote, r as Button, s as Field, u as TextInput } from "./ui-CGkjkGGn.mjs";
import { o as minutesLabel, s as toman } from "./fa-D0mpco5k.mjs";
import { f as createBookingFn, s as availabilityFn, w as publicBusinessFn } from "./fns-CBlOdITi.mjs";
import { n as useCurrentUserState } from "./use-current-user-B7Cbrtsy.mjs";
import { n as Shell } from "./shell-B3P9KCBZ.mjs";
import { n as formatDay, t as formatClock } from "./format-Di5o4uYf.mjs";
import { t as JalaliCalendar } from "./jalali-calendar-BvBxdlSi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book-ab6wOGlh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function idempotency() {
	return `web-${crypto.randomUUID()}`;
}
function BookPage() {
	const { slug } = Route.useParams();
	const { user, isPending } = useCurrentUserState();
	const [biz, setBiz] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [serviceId, setServiceId] = (0, import_react.useState)("");
	const [staffId, setStaffId] = (0, import_react.useState)(null);
	const [day, setDay] = (0, import_react.useState)("");
	const [slots, setSlots] = (0, import_react.useState)([]);
	const [slotLoading, setSlotLoading] = (0, import_react.useState)(false);
	const [start, setStart] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let live = true;
		publicBusinessFn({ data: { slug } }).then((res) => {
			if (!live) return;
			if (!res.ok) {
				setError(res.error);
				return;
			}
			setBiz(res.data);
			setServiceId(res.data.services[0]?.id ?? "");
			setDay(todayYmd(res.data.timezone));
		});
		return () => {
			live = false;
		};
	}, [slug]);
	const service = biz?.services.find((item) => item.id === serviceId);
	const staffChoices = (0, import_react.useMemo)(() => biz?.staff.filter((person) => person.serviceIds.includes(serviceId)) ?? [], [biz, serviceId]);
	(0, import_react.useEffect)(() => {
		if (!biz || !serviceId || !day) return;
		let live = true;
		setSlotLoading(true);
		setStart("");
		availabilityFn({ data: {
			businessId: biz.id,
			serviceId,
			staffId: staffId ?? "",
			day
		} }).then((res) => {
			if (!live) return;
			setSlots(res.ok ? res.data.slots : []);
			if (!res.ok) setError(res.error);
			setSlotLoading(false);
		});
		return () => {
			live = false;
		};
	}, [
		biz,
		serviceId,
		staffId,
		day
	]);
	async function confirm() {
		if (!biz || !start) return;
		setPending(true);
		const res = await createBookingFn({ data: {
			businessId: biz.id,
			serviceId,
			staffId,
			start,
			note,
			idempotencyKey: idempotency()
		} });
		setPending(false);
		if (!res.ok) {
			toast.error(res.error);
			return;
		}
		setDone(res.data.id);
		toast.success("نوبت ثبت شد");
	}
	if (error && !biz) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
		title: "رزرو ممکن نیست",
		body: error
	}) });
	if (!biz) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }) });
	const min = todayYmd(biz.timezone);
	const max = addDaysYmd(min, biz.maxHorizonDays, biz.timezone);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4 flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
			className: "text-3xl font-extrabold",
			children: ["رزرو در ", biz.name]
		}), biz.isDemo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			tone: "copper",
			children: "تمرین با داده نمونه"
		}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/b/$slug",
			params: { slug },
			className: "text-sm font-semibold text-jade",
			children: "بازگشت به صفحه"
		})]
	}), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-xl font-bold",
			children: "نوبت ثبت شد"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-6 text-muted",
			children: "جزئیات در «نوبت‌های من» است. پیامک ارسال نشده؛ فقط اعلان داخلی ثبت شد."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/me",
			className: "mt-4 inline-flex min-h-11 items-center rounded-xl bg-jade px-4 font-semibold text-on-jade",
			children: "مشاهده نوبت‌ها"
		})
	] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[1fr_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-bold",
				children: "۱. خدمت"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-2",
				children: biz.services.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setServiceId(item.id),
					className: `rounded-xl border px-3 py-3 text-start ${item.id === serviceId ? "border-jade bg-jade-soft" : "border-line"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: toman(item.priceToman)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm text-muted",
						children: [minutesLabel(item.durationMinutes), item.bufferMinutes ? ` + ${minutesLabel(item.bufferMinutes)} آماده‌سازی` : ""]
					})]
				}, item.id))
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-bold",
				children: "۲. متخصص"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [biz.allowAnyStaff ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `min-h-11 rounded-full px-4 text-sm ${staffId === null ? "bg-jade text-on-jade" : "border border-line"}`,
					onClick: () => setStaffId(null),
					children: "اولین متخصص آزاد"
				}) : null, staffChoices.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `min-h-11 rounded-full px-4 text-sm ${staffId === person.id ? "bg-jade text-on-jade" : "border border-line"}`,
					onClick: () => setStaffId(person.id),
					children: person.name
				}, person.id))]
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JalaliCalendar, {
					value: day || min,
					onChange: setDay,
					min,
					max
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-bold",
						children: ["۳. زمان ", day ? formatDay(day) : ""]
					}),
					slotLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-3 h-16" }) : null,
					!slotLoading && slots.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "در این روز وقت آزادی نیست."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-3 gap-2 sm:grid-cols-4",
						children: slots.map((slot) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setStart(slot.start),
							className: `min-h-11 rounded-xl text-sm tabular-nums ${start === slot.start ? "bg-ink text-on-ink" : "border border-line"}`,
							children: formatClock(slot.start, biz.timezone)
						}, slot.start))
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "یادداشت برای کسب‌وکار",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: note,
							onChange: (e) => setNote(e.target.value),
							maxLength: 500
						})
					}),
					service && start ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm",
						children: [
							service.name,
							"، ",
							formatClock(start, biz.timezone),
							"، ",
							toman(service.priceToman)
						]
					}) : null,
					isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-3 h-11" }) : null,
					!isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: "برای ثبت نوبت وارد شوید." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							search: { next: `/b/${slug}/book` },
							className: "inline-flex min-h-11 items-center justify-center rounded-xl bg-ink font-semibold text-on-ink",
							children: "ورود"
						})]
					}) : null,
					user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3 w-full",
						disabled: !start || pending,
						onClick: confirm,
						children: pending ? "در حال ثبت" : "تأیید رزرو"
					}) : null
				] })
			]
		})]
	})] });
}
//#endregion
export { BookPage as component };
