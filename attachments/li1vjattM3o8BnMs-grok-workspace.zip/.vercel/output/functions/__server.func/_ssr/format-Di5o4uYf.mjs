import { d as civilInZone } from "./domain-DOE5vDbR.mjs";
import { a as faNum, i as clockLabel, r as WEEKDAYS_FA } from "./fa-D0mpco5k.mjs";
import { n as toGregorian, r as toJalaali, t as jalaaliMonthLength } from "../_libs/jalaali-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-Di5o4uYf.js
function gregorianToJalali(year, month, day) {
	return toJalaali(year, month, day);
}
function jalaliToGregorian(jy, jm, jd) {
	return toGregorian(jy, jm, jd);
}
function monthLength(jy, jm) {
	return jalaaliMonthLength(jy, jm);
}
var JMONTHS = [
	"فروردین",
	"اردیبهشت",
	"خرداد",
	"تیر",
	"مرداد",
	"شهریور",
	"مهر",
	"آبان",
	"آذر",
	"دی",
	"بهمن",
	"اسفند"
];
function jalaliMonthName(jm) {
	return JMONTHS[jm - 1] ?? "";
}
function formatWhen(iso, timeZone) {
	const c = civilInZone(new Date(iso), timeZone);
	const j = gregorianToJalali(c.year, c.month, c.day);
	return `${WEEKDAYS_FA[c.weekday]} ${faNum(j.jd)} ${jalaliMonthName(j.jm)}، ${clockLabel(c.hour * 60 + c.minute)}`;
}
function formatDay(ymd) {
	const [y, m, d] = ymd.split("-").map(Number);
	const j = gregorianToJalali(y, m, d);
	return `${faNum(j.jd)} ${jalaliMonthName(j.jm)} ${faNum(j.jy)}`;
}
function formatClock(iso, timeZone) {
	const c = civilInZone(new Date(iso), timeZone);
	return clockLabel(c.hour * 60 + c.minute);
}
//#endregion
export { jalaliMonthName as a, gregorianToJalali as i, formatDay as n, jalaliToGregorian as o, formatWhen as r, monthLength as s, formatClock as t };
