import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-CGkjkGGn.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Button({ variant = "primary", className, ...props }) {
	const styles = {
		primary: "bg-jade text-on-jade hover:bg-jade-deep",
		quiet: "bg-card text-ink border border-line hover:bg-paper",
		danger: "bg-danger-soft text-danger hover:bg-danger hover:text-on-ink",
		ink: "bg-ink text-on-ink hover:bg-jade-deep"
	}[variant];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition disabled:opacity-50", styles, className),
		...props
	});
}
function Card({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-card border border-line bg-card p-5 shadow-sm", className),
		children
	});
}
function Badge({ tone = "jade", children }) {
	const styles = {
		jade: "bg-jade-soft text-jade-deep",
		copper: "bg-copper-soft text-copper",
		muted: "bg-paper-deep text-muted",
		danger: "bg-danger-soft text-danger"
	}[tone];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold", styles),
		children
	});
}
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1.5 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted",
				children: hint
			}) : null
		]
	});
}
function TextInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn("min-h-11 w-full rounded-xl border border-line bg-card px-3 text-sm outline-none", props.className)
	});
}
function Area(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cn("min-h-24 w-full rounded-xl border border-line bg-card px-3 py-2 text-sm outline-none", props.className)
	});
}
function Select(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: cn("min-h-11 w-full rounded-xl border border-line bg-card px-3 text-sm outline-none", props.className)
	});
}
function Empty({ title, body, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid justify-items-center gap-3 rounded-card border border-dashed border-line bg-card px-6 py-12 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm text-muted",
				children: body
			}),
			action
		]
	});
}
function Skeleton({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("animate-pulse rounded-xl bg-paper-deep", className) });
}
function ErrorNote({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-xl bg-danger-soft px-3 py-2 text-sm text-danger",
		children
	});
}
//#endregion
export { Empty as a, Select as c, cn as d, Card as i, Skeleton as l, Badge as n, ErrorNote as o, Button as r, Field as s, Area as t, TextInput as u };
