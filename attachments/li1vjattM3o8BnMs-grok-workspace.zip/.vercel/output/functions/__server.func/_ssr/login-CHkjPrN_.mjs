import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as GROK_PROVIDERS } from "./verify.server-BdtX1BJw.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Route$18 } from "./router-CUtJgkix.mjs";
import { i as Card, o as ErrorNote, r as Button, s as Field, u as TextInput } from "./ui-CGkjkGGn.mjs";
import { r as signIn, t as authClient } from "./client-1vAx-gM_.mjs";
import { n as Shell } from "./shell-B3P9KCBZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-CHkjPrN_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const { next } = Route$18.useSearch();
	const router = useRouter();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		setError("");
		setPending(true);
		const result = mode === "up" ? await authClient.signUp.email({
			email,
			password,
			name,
			callbackURL: next
		}) : await authClient.signIn.email({
			email,
			password,
			callbackURL: next
		});
		setPending(false);
		if (result.error) {
			setError(result.error.message || "ورود انجام نشد");
			return;
		}
		toast.success(mode === "up" ? "حساب ساخته شد" : "وارد شدید");
		await router.invalidate();
		window.location.assign(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-md gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-extrabold",
				children: mode === "up" ? "ساخت حساب" : "ورود"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "ایمیل و رمز، یا ادامه با گوگل و ایکس. رمز یک‌بارمصرف پیامکی در این نسخه نیست."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: mode === "in" ? "ink" : "quiet",
					onClick: () => setMode("in"),
					children: "ورود"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: mode === "up" ? "ink" : "quiet",
					onClick: () => setMode("up"),
					children: "ثبت‌نام"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3",
				onSubmit: submit,
				children: [
					mode === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نام",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: name,
							onChange: (e) => setName(e.target.value),
							required: true,
							minLength: 2,
							autoComplete: "name"
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "ایمیل",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							type: "email",
							dir: "ltr",
							value: email,
							onChange: (e) => setEmail(e.target.value),
							required: true,
							autoComplete: "email",
							className: "text-left"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "رمز عبور",
						hint: "حداقل ۸ نویسه",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							type: "password",
							dir: "ltr",
							value: password,
							onChange: (e) => setPassword(e.target.value),
							required: true,
							minLength: 8,
							autoComplete: mode === "up" ? "new-password" : "current-password",
							className: "text-left"
						})
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: error }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: pending,
						children: pending ? "لطفاً صبر کنید" : mode === "up" ? "ساخت حساب" : "ورود"
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "quiet",
					onClick: () => signIn(provider.providerId, { callbackURL: next }),
					children: ["ادامه با ", provider.label]
				}, provider.providerId))
			})
		]
	}) });
}
//#endregion
export { LoginPage as component };
