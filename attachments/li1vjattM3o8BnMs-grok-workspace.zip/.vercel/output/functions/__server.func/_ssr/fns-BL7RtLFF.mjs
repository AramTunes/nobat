import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { A as rescheduleBooking, B as updateBusiness, C as manageBusiness, D as myNotifications, E as myBookings, F as saveSettings, I as saveStaff, L as setBookingStatus, M as saveCustomer, N as saveSchedule, O as publicBusiness, P as saveService, R as setBusinessModeration, S as listCustomers, T as me, V as updateProfile, _ as deleteBusiness, a as adminBusinesses, b as listBusinesses, c as adminUsers, f as claimAdmin, g as dashboard, h as createDemo, i as adminAudit, j as saveCategory, k as removeHoliday, l as availability, m as createBusiness, o as adminCategories, p as createBooking, r as addHoliday, s as adminOverview, t as DomainError, u as businessBookings, w as markNotificationRead, x as listCategories } from "./domain-DOE5vDbR.mjs";
import { t as authMiddleware } from "./middleware-CXzNYJ2C.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fns-BL7RtLFF.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
async function guard(fn) {
	try {
		return {
			ok: true,
			data: await fn()
		};
	} catch (err) {
		if (err instanceof DomainError) return {
			ok: false,
			error: err.message,
			code: err.code
		};
		if ((err instanceof Error ? err.message : "") === "Unauthorized") return {
			ok: false,
			error: "برای ادامه وارد شوید",
			code: "UNAUTHORIZED"
		};
		console.error("[nobat]", err instanceof Error ? err.name : "error");
		return {
			ok: false,
			error: "خطای داخلی. دوباره تلاش کنید.",
			code: "INTERNAL"
		};
	}
}
var categoriesFn_createServerFn_handler = createServerRpc({
	id: "6c23b4ab1f10404fb486348a5735bf3d2791c92e07a9ab3d58ab6068487f0f3d",
	name: "categoriesFn",
	filename: "src/server/fns.ts"
}, (opts) => categoriesFn.__executeServer(opts));
var categoriesFn = createServerFn({ method: "GET" }).handler(categoriesFn_createServerFn_handler, async () => guard(() => listCategories()));
var businessesFn_createServerFn_handler = createServerRpc({
	id: "7349bff5d01afc7a4c0f65930ca59d0b2c866777deda10a8d76366e49e781dfc",
	name: "businessesFn",
	filename: "src/server/fns.ts"
}, (opts) => businessesFn.__executeServer(opts));
var businessesFn = createServerFn({ method: "POST" }).validator((input) => input).handler(businessesFn_createServerFn_handler, async ({ data }) => guard(() => listBusinesses(data)));
var publicBusinessFn_createServerFn_handler = createServerRpc({
	id: "b42c4426d383b5826a3b245030c6797926b746347fc8a2024790770854e6e067",
	name: "publicBusinessFn",
	filename: "src/server/fns.ts"
}, (opts) => publicBusinessFn.__executeServer(opts));
var publicBusinessFn = createServerFn({ method: "POST" }).validator((input) => input).handler(publicBusinessFn_createServerFn_handler, async ({ data }) => guard(() => publicBusiness(String(data?.slug ?? ""))));
var availabilityFn_createServerFn_handler = createServerRpc({
	id: "b4bca9dc069c2504dcc9fab6f4bd29989dadba18ea951a8598d88aa2a5cab8c6",
	name: "availabilityFn",
	filename: "src/server/fns.ts"
}, (opts) => availabilityFn.__executeServer(opts));
var availabilityFn = createServerFn({ method: "POST" }).validator((input) => input).handler(availabilityFn_createServerFn_handler, async ({ data }) => guard(() => availability(data)));
var meFn_createServerFn_handler = createServerRpc({
	id: "25017e5662643f1a6637fe571fdea47755690c6c42db16492c4bde2e71d7ce97",
	name: "meFn",
	filename: "src/server/fns.ts"
}, (opts) => meFn.__executeServer(opts));
var meFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(meFn_createServerFn_handler, async ({ context }) => guard(() => me(context.userId)));
var updateProfileFn_createServerFn_handler = createServerRpc({
	id: "18479703ab298a0e327e2b316f91b4ba8f70fb24b182d20f5290cb8f32d8cb5d",
	name: "updateProfileFn",
	filename: "src/server/fns.ts"
}, (opts) => updateProfileFn.__executeServer(opts));
var updateProfileFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(updateProfileFn_createServerFn_handler, async ({ data, context }) => guard(() => updateProfile(context.userId, data)));
var claimAdminFn_createServerFn_handler = createServerRpc({
	id: "d56b691ff1f3f09d0c6b3d4f0d472b65baabdd6f2ffd972c65f5f2268231ce52",
	name: "claimAdminFn",
	filename: "src/server/fns.ts"
}, (opts) => claimAdminFn.__executeServer(opts));
var claimAdminFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(claimAdminFn_createServerFn_handler, async ({ context }) => guard(() => claimAdmin(context.userId)));
var createBusinessFn_createServerFn_handler = createServerRpc({
	id: "6ace3f01041e812ce589ca779d458f916c4fda314db0e1a0a096e31726b07a78",
	name: "createBusinessFn",
	filename: "src/server/fns.ts"
}, (opts) => createBusinessFn.__executeServer(opts));
var createBusinessFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createBusinessFn_createServerFn_handler, async ({ data, context }) => guard(() => createBusiness(context.userId, data)));
var createDemoFn_createServerFn_handler = createServerRpc({
	id: "4ea1dff6e50320e3614c673e0e9c1b64815a1a599587fc02ff6ac00f81341cb6",
	name: "createDemoFn",
	filename: "src/server/fns.ts"
}, (opts) => createDemoFn.__executeServer(opts));
var createDemoFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createDemoFn_createServerFn_handler, async ({ context }) => guard(() => createDemo(context.userId)));
var updateBusinessFn_createServerFn_handler = createServerRpc({
	id: "996f338f078c53828ce959c9218f73fd637e91c5e87b50decfe311b774674119",
	name: "updateBusinessFn",
	filename: "src/server/fns.ts"
}, (opts) => updateBusinessFn.__executeServer(opts));
var updateBusinessFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(updateBusinessFn_createServerFn_handler, async ({ data, context }) => guard(() => updateBusiness(context.userId, data)));
var deleteBusinessFn_createServerFn_handler = createServerRpc({
	id: "cdb61e4de4895d51d7dac559e9e711b1d006cdc3fa2f5c7f13f32d1c454b0bb2",
	name: "deleteBusinessFn",
	filename: "src/server/fns.ts"
}, (opts) => deleteBusinessFn.__executeServer(opts));
var deleteBusinessFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(deleteBusinessFn_createServerFn_handler, async ({ data, context }) => guard(() => deleteBusiness(context.userId, String(data?.businessId ?? ""))));
var manageBusinessFn_createServerFn_handler = createServerRpc({
	id: "a4f6c125a9271441be714ef3d9c00bd15f7843c2b89b53296ac25c03ee1864a2",
	name: "manageBusinessFn",
	filename: "src/server/fns.ts"
}, (opts) => manageBusinessFn.__executeServer(opts));
var manageBusinessFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(manageBusinessFn_createServerFn_handler, async ({ data, context }) => guard(() => manageBusiness(context.userId, String(data?.businessId ?? ""))));
var saveServiceFn_createServerFn_handler = createServerRpc({
	id: "e6930c33ab1349463df1788ae23c23dc268560357ac113f3f7f8a7ce075319b4",
	name: "saveServiceFn",
	filename: "src/server/fns.ts"
}, (opts) => saveServiceFn.__executeServer(opts));
var saveServiceFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveServiceFn_createServerFn_handler, async ({ data, context }) => guard(() => saveService(context.userId, data)));
var saveStaffFn_createServerFn_handler = createServerRpc({
	id: "daca6c86e087ce922bbc96b8e364cef3676a2b9d326c7e9fa7f8047334d1e814",
	name: "saveStaffFn",
	filename: "src/server/fns.ts"
}, (opts) => saveStaffFn.__executeServer(opts));
var saveStaffFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveStaffFn_createServerFn_handler, async ({ data, context }) => guard(() => saveStaff(context.userId, data)));
var saveScheduleFn_createServerFn_handler = createServerRpc({
	id: "308801386a933d687ec15b7b8efa1fa305bd5827a1ecafd74dd5ca5485e9d651",
	name: "saveScheduleFn",
	filename: "src/server/fns.ts"
}, (opts) => saveScheduleFn.__executeServer(opts));
var saveScheduleFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveScheduleFn_createServerFn_handler, async ({ data, context }) => guard(() => saveSchedule(context.userId, data)));
var addHolidayFn_createServerFn_handler = createServerRpc({
	id: "990a6dbe8c3f6a984636d581da3f05025e967720f82e98eaf6a33dc06728a990",
	name: "addHolidayFn",
	filename: "src/server/fns.ts"
}, (opts) => addHolidayFn.__executeServer(opts));
var addHolidayFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(addHolidayFn_createServerFn_handler, async ({ data, context }) => guard(() => addHoliday(context.userId, data)));
var removeHolidayFn_createServerFn_handler = createServerRpc({
	id: "933ee5b66da560b26ce4ab7babc38b62fb8325c1bdbf7bae49d733c67d95fbe0",
	name: "removeHolidayFn",
	filename: "src/server/fns.ts"
}, (opts) => removeHolidayFn.__executeServer(opts));
var removeHolidayFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(removeHolidayFn_createServerFn_handler, async ({ data, context }) => guard(() => removeHoliday(context.userId, data)));
var createBookingFn_createServerFn_handler = createServerRpc({
	id: "b0eff98059f644469a67ec3e01eeeaac0dca8b92b2983b9a3ba3a99436985467",
	name: "createBookingFn",
	filename: "src/server/fns.ts"
}, (opts) => createBookingFn.__executeServer(opts));
var createBookingFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createBookingFn_createServerFn_handler, async ({ data, context }) => guard(() => createBooking(context.userId, data)));
var setBookingStatusFn_createServerFn_handler = createServerRpc({
	id: "28839415dbc6e8a85e10e77cf7c79c70de55b83c347ac25ccebda44661aea2b0",
	name: "setBookingStatusFn",
	filename: "src/server/fns.ts"
}, (opts) => setBookingStatusFn.__executeServer(opts));
var setBookingStatusFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(setBookingStatusFn_createServerFn_handler, async ({ data, context }) => guard(() => setBookingStatus(context.userId, data)));
var rescheduleBookingFn_createServerFn_handler = createServerRpc({
	id: "d8e032542dfc2d91bbce47c9ca5eaba198fdcabe798abb19d7d28bca73397bda",
	name: "rescheduleBookingFn",
	filename: "src/server/fns.ts"
}, (opts) => rescheduleBookingFn.__executeServer(opts));
var rescheduleBookingFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(rescheduleBookingFn_createServerFn_handler, async ({ data, context }) => guard(() => rescheduleBooking(context.userId, data)));
var myBookingsFn_createServerFn_handler = createServerRpc({
	id: "de7c228c9f272e1aa8de523ed833f4df253eb7a615296900706949cc8c08ef64",
	name: "myBookingsFn",
	filename: "src/server/fns.ts"
}, (opts) => myBookingsFn.__executeServer(opts));
var myBookingsFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(myBookingsFn_createServerFn_handler, async ({ context }) => guard(() => myBookings(context.userId)));
var businessBookingsFn_createServerFn_handler = createServerRpc({
	id: "7bcd952f8caaaa555e3946cedacb11b91e6f084a46a6f58cd65b35393d824f39",
	name: "businessBookingsFn",
	filename: "src/server/fns.ts"
}, (opts) => businessBookingsFn.__executeServer(opts));
var businessBookingsFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(businessBookingsFn_createServerFn_handler, async ({ data, context }) => guard(() => businessBookings(context.userId, data)));
var customersFn_createServerFn_handler = createServerRpc({
	id: "6b064c5374cb1d6e7fd0c1e6d0a81fdf9fb3cb3072a25892fb9110950394d1b5",
	name: "customersFn",
	filename: "src/server/fns.ts"
}, (opts) => customersFn.__executeServer(opts));
var customersFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(customersFn_createServerFn_handler, async ({ data, context }) => guard(() => listCustomers(context.userId, data)));
var saveCustomerFn_createServerFn_handler = createServerRpc({
	id: "04f2fa982c1f194004be3410221cf60237b12d5158482e17e2e46ae07773e31b",
	name: "saveCustomerFn",
	filename: "src/server/fns.ts"
}, (opts) => saveCustomerFn.__executeServer(opts));
var saveCustomerFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveCustomerFn_createServerFn_handler, async ({ data, context }) => guard(() => saveCustomer(context.userId, data)));
var dashboardFn_createServerFn_handler = createServerRpc({
	id: "fed126898eab3d80c5f4ab5131cb05d9e5152a95655a2898a4d35ed6b06df872",
	name: "dashboardFn",
	filename: "src/server/fns.ts"
}, (opts) => dashboardFn.__executeServer(opts));
var dashboardFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(dashboardFn_createServerFn_handler, async ({ data, context }) => guard(() => dashboard(context.userId, data)));
var notificationsFn_createServerFn_handler = createServerRpc({
	id: "b24a65c539428cc3a4813c3f65e790a463c1c83e6180998317c7c9589e3a761a",
	name: "notificationsFn",
	filename: "src/server/fns.ts"
}, (opts) => notificationsFn.__executeServer(opts));
var notificationsFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(notificationsFn_createServerFn_handler, async ({ context }) => guard(() => myNotifications(context.userId)));
var markReadFn_createServerFn_handler = createServerRpc({
	id: "cf8b9fb98c52dc31151af8310c5cb7c538b5711616aa0bbe50bd7d9b25ad6875",
	name: "markReadFn",
	filename: "src/server/fns.ts"
}, (opts) => markReadFn.__executeServer(opts));
var markReadFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(markReadFn_createServerFn_handler, async ({ data, context }) => guard(() => markNotificationRead(context.userId, data)));
var adminOverviewFn_createServerFn_handler = createServerRpc({
	id: "44704ab598565132ffe072c0bc9d1dcf24fb30981a34a5105f332af1336ff9f1",
	name: "adminOverviewFn",
	filename: "src/server/fns.ts"
}, (opts) => adminOverviewFn.__executeServer(opts));
var adminOverviewFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminOverviewFn_createServerFn_handler, async ({ context }) => guard(() => adminOverview(context.userId)));
var adminUsersFn_createServerFn_handler = createServerRpc({
	id: "d3ffab79458fc9f232010354d1c622015859ddd465f5179583de3c613c2cac35",
	name: "adminUsersFn",
	filename: "src/server/fns.ts"
}, (opts) => adminUsersFn.__executeServer(opts));
var adminUsersFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminUsersFn_createServerFn_handler, async ({ data, context }) => guard(() => adminUsers(context.userId, data)));
var adminBusinessesFn_createServerFn_handler = createServerRpc({
	id: "39372f6c2c28ba3971d19977e02c162f6ef0158c356fe92efc1955b5a69a0419",
	name: "adminBusinessesFn",
	filename: "src/server/fns.ts"
}, (opts) => adminBusinessesFn.__executeServer(opts));
var adminBusinessesFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminBusinessesFn_createServerFn_handler, async ({ data, context }) => guard(() => adminBusinesses(context.userId, data)));
var moderateBusinessFn_createServerFn_handler = createServerRpc({
	id: "bd4faaf3326626079f1b609cb869cb4ea1f9d16bc7ae7afdd863758387d7d059",
	name: "moderateBusinessFn",
	filename: "src/server/fns.ts"
}, (opts) => moderateBusinessFn.__executeServer(opts));
var moderateBusinessFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(moderateBusinessFn_createServerFn_handler, async ({ data, context }) => guard(() => setBusinessModeration(context.userId, data)));
var adminCategoriesFn_createServerFn_handler = createServerRpc({
	id: "2bb794dc3a873a03794e3107674eabf88a1ee79f909acb1aa9d81b85726c54c0",
	name: "adminCategoriesFn",
	filename: "src/server/fns.ts"
}, (opts) => adminCategoriesFn.__executeServer(opts));
var adminCategoriesFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminCategoriesFn_createServerFn_handler, async ({ context }) => guard(() => adminCategories(context.userId)));
var saveCategoryFn_createServerFn_handler = createServerRpc({
	id: "592714faf47eecf2789aaf9758279c131bd1653b2aa037a68065d5150ec0c226",
	name: "saveCategoryFn",
	filename: "src/server/fns.ts"
}, (opts) => saveCategoryFn.__executeServer(opts));
var saveCategoryFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveCategoryFn_createServerFn_handler, async ({ data, context }) => guard(() => saveCategory(context.userId, data)));
var adminAuditFn_createServerFn_handler = createServerRpc({
	id: "cf60054fcec41302e19fbc121c3ef77d0c6e9f7c836a5984d28ef6e816f8a157",
	name: "adminAuditFn",
	filename: "src/server/fns.ts"
}, (opts) => adminAuditFn.__executeServer(opts));
var adminAuditFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminAuditFn_createServerFn_handler, async ({ context }) => guard(() => adminAudit(context.userId)));
var saveSettingsFn_createServerFn_handler = createServerRpc({
	id: "7f9c91c538bc5ac58f6ee318e8e272d073ac6459aa86b87827087cb5e79dc442",
	name: "saveSettingsFn",
	filename: "src/server/fns.ts"
}, (opts) => saveSettingsFn.__executeServer(opts));
var saveSettingsFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveSettingsFn_createServerFn_handler, async ({ data, context }) => guard(() => saveSettings(context.userId, data)));
//#endregion
export { addHolidayFn_createServerFn_handler, adminAuditFn_createServerFn_handler, adminBusinessesFn_createServerFn_handler, adminCategoriesFn_createServerFn_handler, adminOverviewFn_createServerFn_handler, adminUsersFn_createServerFn_handler, availabilityFn_createServerFn_handler, businessBookingsFn_createServerFn_handler, businessesFn_createServerFn_handler, categoriesFn_createServerFn_handler, claimAdminFn_createServerFn_handler, createBookingFn_createServerFn_handler, createBusinessFn_createServerFn_handler, createDemoFn_createServerFn_handler, customersFn_createServerFn_handler, dashboardFn_createServerFn_handler, deleteBusinessFn_createServerFn_handler, manageBusinessFn_createServerFn_handler, markReadFn_createServerFn_handler, meFn_createServerFn_handler, moderateBusinessFn_createServerFn_handler, myBookingsFn_createServerFn_handler, notificationsFn_createServerFn_handler, publicBusinessFn_createServerFn_handler, removeHolidayFn_createServerFn_handler, rescheduleBookingFn_createServerFn_handler, saveCategoryFn_createServerFn_handler, saveCustomerFn_createServerFn_handler, saveScheduleFn_createServerFn_handler, saveServiceFn_createServerFn_handler, saveSettingsFn_createServerFn_handler, saveStaffFn_createServerFn_handler, setBookingStatusFn_createServerFn_handler, updateBusinessFn_createServerFn_handler, updateProfileFn_createServerFn_handler };
