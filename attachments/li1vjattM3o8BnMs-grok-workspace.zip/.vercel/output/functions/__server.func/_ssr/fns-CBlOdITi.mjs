import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-CXzNYJ2C.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fns-CBlOdITi.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var categoriesFn = createServerFn({ method: "GET" }).handler(createSsrRpc("6c23b4ab1f10404fb486348a5735bf3d2791c92e07a9ab3d58ab6068487f0f3d"));
var businessesFn = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("7349bff5d01afc7a4c0f65930ca59d0b2c866777deda10a8d76366e49e781dfc"));
var publicBusinessFn = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("b42c4426d383b5826a3b245030c6797926b746347fc8a2024790770854e6e067"));
var availabilityFn = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("b4bca9dc069c2504dcc9fab6f4bd29989dadba18ea951a8598d88aa2a5cab8c6"));
var meFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("25017e5662643f1a6637fe571fdea47755690c6c42db16492c4bde2e71d7ce97"));
var updateProfileFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("18479703ab298a0e327e2b316f91b4ba8f70fb24b182d20f5290cb8f32d8cb5d"));
var claimAdminFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("d56b691ff1f3f09d0c6b3d4f0d472b65baabdd6f2ffd972c65f5f2268231ce52"));
var createBusinessFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("6ace3f01041e812ce589ca779d458f916c4fda314db0e1a0a096e31726b07a78"));
var createDemoFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("4ea1dff6e50320e3614c673e0e9c1b64815a1a599587fc02ff6ac00f81341cb6"));
var updateBusinessFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("996f338f078c53828ce959c9218f73fd637e91c5e87b50decfe311b774674119"));
var deleteBusinessFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("cdb61e4de4895d51d7dac559e9e711b1d006cdc3fa2f5c7f13f32d1c454b0bb2"));
var manageBusinessFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("a4f6c125a9271441be714ef3d9c00bd15f7843c2b89b53296ac25c03ee1864a2"));
var saveServiceFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("e6930c33ab1349463df1788ae23c23dc268560357ac113f3f7f8a7ce075319b4"));
var saveStaffFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("daca6c86e087ce922bbc96b8e364cef3676a2b9d326c7e9fa7f8047334d1e814"));
var saveScheduleFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("308801386a933d687ec15b7b8efa1fa305bd5827a1ecafd74dd5ca5485e9d651"));
var addHolidayFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("990a6dbe8c3f6a984636d581da3f05025e967720f82e98eaf6a33dc06728a990"));
var removeHolidayFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("933ee5b66da560b26ce4ab7babc38b62fb8325c1bdbf7bae49d733c67d95fbe0"));
var createBookingFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("b0eff98059f644469a67ec3e01eeeaac0dca8b92b2983b9a3ba3a99436985467"));
var setBookingStatusFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("28839415dbc6e8a85e10e77cf7c79c70de55b83c347ac25ccebda44661aea2b0"));
var rescheduleBookingFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("d8e032542dfc2d91bbce47c9ca5eaba198fdcabe798abb19d7d28bca73397bda"));
var myBookingsFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("de7c228c9f272e1aa8de523ed833f4df253eb7a615296900706949cc8c08ef64"));
var businessBookingsFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("7bcd952f8caaaa555e3946cedacb11b91e6f084a46a6f58cd65b35393d824f39"));
var customersFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("6b064c5374cb1d6e7fd0c1e6d0a81fdf9fb3cb3072a25892fb9110950394d1b5"));
var saveCustomerFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("04f2fa982c1f194004be3410221cf60237b12d5158482e17e2e46ae07773e31b"));
var dashboardFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("fed126898eab3d80c5f4ab5131cb05d9e5152a95655a2898a4d35ed6b06df872"));
var notificationsFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("b24a65c539428cc3a4813c3f65e790a463c1c83e6180998317c7c9589e3a761a"));
var markReadFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("cf8b9fb98c52dc31151af8310c5cb7c538b5711616aa0bbe50bd7d9b25ad6875"));
var adminOverviewFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("44704ab598565132ffe072c0bc9d1dcf24fb30981a34a5105f332af1336ff9f1"));
var adminUsersFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("d3ffab79458fc9f232010354d1c622015859ddd465f5179583de3c613c2cac35"));
var adminBusinessesFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("39372f6c2c28ba3971d19977e02c162f6ef0158c356fe92efc1955b5a69a0419"));
var moderateBusinessFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("bd4faaf3326626079f1b609cb869cb4ea1f9d16bc7ae7afdd863758387d7d059"));
var adminCategoriesFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("2bb794dc3a873a03794e3107674eabf88a1ee79f909acb1aa9d81b85726c54c0"));
var saveCategoryFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("592714faf47eecf2789aaf9758279c131bd1653b2aa037a68065d5150ec0c226"));
var adminAuditFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("cf60054fcec41302e19fbc121c3ef77d0c6e9f7c836a5984d28ef6e816f8a157"));
var saveSettingsFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("7f9c91c538bc5ac58f6ee318e8e272d073ac6459aa86b87827087cb5e79dc442"));
//#endregion
export { saveServiceFn as A, notificationsFn as C, saveCategoryFn as D, rescheduleBookingFn as E, updateProfileFn as F, saveStaffFn as M, setBookingStatusFn as N, saveCustomerFn as O, updateBusinessFn as P, myBookingsFn as S, removeHolidayFn as T, deleteBusinessFn as _, adminOverviewFn as a, meFn as b, businessBookingsFn as c, claimAdminFn as d, createBookingFn as f, dashboardFn as g, customersFn as h, adminCategoriesFn as i, saveSettingsFn as j, saveScheduleFn as k, businessesFn as l, createDemoFn as m, adminAuditFn as n, adminUsersFn as o, createBusinessFn as p, adminBusinessesFn as r, availabilityFn as s, addHolidayFn as t, categoriesFn as u, manageBusinessFn as v, publicBusinessFn as w, moderateBusinessFn as x, markReadFn as y };
