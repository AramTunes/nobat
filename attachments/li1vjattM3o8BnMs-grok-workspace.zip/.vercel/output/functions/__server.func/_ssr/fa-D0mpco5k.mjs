//#region node_modules/.nitro/vite/services/ssr/assets/fa-D0mpco5k.js
var DIGITS = "۰۱۲۳۴۵۶۷۸۹";
function faNum(value) {
	return String(value).replace(/\d/g, (d) => DIGITS[Number(d)] ?? d);
}
function toman(amount) {
	return `${faNum(Math.max(0, Math.round(amount)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, "٬"))} تومان`;
}
function minutesLabel(total) {
	const h = Math.floor(total / 60);
	const m = total % 60;
	if (h && m) return `${faNum(h)} ساعت و ${faNum(m)} دقیقه`;
	if (h) return `${faNum(h)} ساعت`;
	return `${faNum(m)} دقیقه`;
}
function clockLabel(mins) {
	const h = Math.floor(mins / 60);
	const m = mins % 60;
	return faNum(`${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`);
}
var WEEKDAYS_FA = [
	"یکشنبه",
	"دوشنبه",
	"سه‌شنبه",
	"چهارشنبه",
	"پنجشنبه",
	"جمعه",
	"شنبه"
];
var STATUS_FA = {
	pending: "در انتظار",
	confirmed: "تأییدشده",
	completed: "انجام‌شده",
	cancelled: "لغوشده",
	no_show: "عدم مراجعه"
};
var ROLE_FA = {
	owner: "مالک",
	manager: "مدیر",
	staff: "کارمند"
};
//#endregion
export { faNum as a, clockLabel as i, STATUS_FA as n, minutesLabel as o, WEEKDAYS_FA as r, toman as s, ROLE_FA as t };
