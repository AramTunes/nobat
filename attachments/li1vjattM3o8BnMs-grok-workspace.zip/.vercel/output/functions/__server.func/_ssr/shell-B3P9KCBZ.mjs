import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link, x as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as hasGateSessionMarker } from "./verify.server-BdtX1BJw.mjs";
import { l as CalendarClock, u as Bell } from "../_libs/lucide-react.mjs";
import { i as signOut } from "./client-1vAx-gM_.mjs";
import { n as useCurrentUserState, t as useCurrentUser } from "./use-current-user-B7Cbrtsy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-B3P9KCBZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var links = [
	{
		to: "/explore",
		label: "کسب‌وکارها"
	},
	{
		to: "/me",
		label: "نوبت‌های من"
	},
	{
		to: "/panel",
		label: "پنل کسب‌وکار"
	}
];
function Shell({ children }) {
	const { user, isPending } = useCurrentUserState();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-20 border-b border-line bg-paper/95 backdrop-blur",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl items-center gap-3 px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2 font-extrabold tracking-tight",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-9 place-items-center rounded-xl bg-jade text-on-jade",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarClock, {
								className: "size-5",
								"aria-hidden": "true"
							})
						}), "نوبتک"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex flex-1 items-center gap-1 overflow-x-auto text-sm",
						children: [links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: link.to,
							className: "shrink-0 rounded-lg px-3 py-2 text-muted hover:bg-card hover:text-ink",
							activeProps: { className: "shrink-0 rounded-lg bg-card px-3 py-2 font-semibold text-ink" },
							children: link.label
						}, link.to)), !isPending && user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/admin",
							className: "shrink-0 rounded-lg px-3 py-2 text-muted hover:bg-card hover:text-ink",
							activeProps: { className: "shrink-0 rounded-lg bg-card px-3 py-2 font-semibold text-ink" },
							children: "مدیریت"
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-8 animate-pulse rounded-full bg-paper-deep" }) : null,
							!isPending && user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/me",
								"aria-label": "اعلان‌ها",
								className: "grid size-11 place-items-center rounded-xl hover:bg-card",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})] }) : null,
							!isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								search: { next: "/" },
								className: "inline-flex min-h-11 items-center rounded-xl bg-ink px-4 text-sm font-semibold text-on-ink",
								children: "ورود"
							}) : null
						]
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto w-full max-w-6xl px-4 py-6",
			children
		})]
	});
}
function Subnav({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-5 flex gap-2 overflow-x-auto pb-1",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: item.to,
			activeOptions: { exact: Boolean(item.exact) },
			className: "shrink-0 rounded-full border border-line bg-card px-4 py-2 text-sm",
			activeProps: { className: "shrink-0 rounded-full bg-jade px-4 py-2 text-sm font-semibold text-on-jade" },
			children: item.label
		}, item.to + item.label))
	});
}
//#endregion
export { Shell as n, Subnav as r, RedirectToSignIn as t };
