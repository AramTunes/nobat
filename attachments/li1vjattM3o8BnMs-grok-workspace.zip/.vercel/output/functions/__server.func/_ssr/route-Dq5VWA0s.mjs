import { C as require_jsx_runtime, g as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Skeleton, n as Badge } from "./ui-CGkjkGGn.mjs";
import { t as ROLE_FA } from "./fa-D0mpco5k.mjs";
import { n as Shell, r as Subnav, t as RedirectToSignIn } from "./shell-B3P9KCBZ.mjs";
import { n as useAccount, r as useBusinessId, t as PanelState } from "./account-Pv_jSsFe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-Dq5VWA0s.js
var import_jsx_runtime = require_jsx_runtime();
function PanelLayout() {
	const account = useAccount();
	const { businessId, choose } = useBusinessId(account.me?.memberships);
	if (account.isPending || account.user && account.loading && !account.me) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }) });
	if (!account.user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	const current = account.me?.memberships.find((item) => item.businessId === businessId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-extrabold",
				children: "پنل کسب‌وکار"
			}), current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 flex flex-wrap items-center gap-2 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ROLE_FA[current.role] ?? current.role }), current.status !== "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: "danger",
					children: current.status === "suspended" ? "تعلیق‌شده" : "غیرفعال"
				}) : null]
			}) : null] }), account.me && account.me.memberships.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: "min-h-11 rounded-xl border border-line bg-card px-3",
				value: businessId,
				onChange: (e) => choose(e.target.value),
				"aria-label": "کسب‌وکار",
				children: account.me.memberships.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: item.businessId,
					children: item.name
				}, item.businessId))
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Subnav, { items: [
			{
				to: "/panel",
				label: "خانه",
				exact: true
			},
			{
				to: "/panel/calendar",
				label: "تقویم"
			},
			{
				to: "/panel/services",
				label: "خدمات"
			},
			{
				to: "/panel/staff",
				label: "همکاران"
			},
			{
				to: "/panel/customers",
				label: "مشتریان"
			},
			{
				to: "/panel/settings",
				label: "تنظیمات"
			}
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelState.Provider, {
			value: {
				businessId,
				memberships: account.me?.memberships ?? []
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
		})
	] });
}
//#endregion
export { PanelLayout as component };
