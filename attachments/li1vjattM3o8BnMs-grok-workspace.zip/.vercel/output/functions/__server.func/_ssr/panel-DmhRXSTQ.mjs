import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Card, l as Skeleton, r as Button, s as Field, u as TextInput } from "./ui-CGkjkGGn.mjs";
import { a as faNum } from "./fa-D0mpco5k.mjs";
import { g as dashboardFn, m as createDemoFn, p as createBusinessFn, u as categoriesFn } from "./fns-CBlOdITi.mjs";
import { i as usePanel } from "./account-Pv_jSsFe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/panel-DmhRXSTQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PanelHome() {
	const { businessId } = usePanel();
	const [categories, setCategories] = (0, import_react.useState)([]);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		city: "",
		phone: "",
		categoryId: "cat-beauty"
	});
	const [dash, setDash] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		categoriesFn().then((res) => {
			if (res.ok) setCategories(res.data);
		});
	}, []);
	(0, import_react.useEffect)(() => {
		if (!businessId) return;
		let live = true;
		setLoading(true);
		dashboardFn({ data: { businessId } }).then((res) => {
			if (!live) return;
			setDash(res.ok ? res.data : null);
			if (!res.ok) toast.error(res.error);
			setLoading(false);
		});
		return () => {
			live = false;
		};
	}, [businessId]);
	if (!businessId) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-xl font-bold",
			children: "کسب‌وکار تازه"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4 grid gap-3",
			onSubmit: async (event) => {
				event.preventDefault();
				const res = await createBusinessFn({ data: {
					...form,
					timezone: "Asia/Tehran"
				} });
				if (!res.ok) {
					toast.error(res.error);
					return;
				}
				localStorage.setItem("nobatak.business", res.data.businessId);
				toast.success("ساخته شد");
				window.location.assign("/panel/services");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نام",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: form.name,
						onChange: (e) => setForm({
							...form,
							name: e.target.value
						}),
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "شهر",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: form.city,
						onChange: (e) => setForm({
							...form,
							city: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "تلفن",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						dir: "ltr",
						className: "text-left",
						value: form.phone,
						onChange: (e) => setForm({
							...form,
							phone: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "دسته",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "min-h-11 rounded-xl border border-line bg-card px-3",
						value: form.categoryId,
						onChange: (e) => setForm({
							...form,
							categoryId: e.target.value
						}),
						children: categories.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: cat.id,
							children: cat.name
						}, cat.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "ساخت کسب‌وکار"
				})
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-bold",
				children: "نمونه قابل حذف"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-6 text-muted",
				children: "یک آرایشگاه با خدمت، همکار و ساعت کاری می‌سازد تا رزرو را امتحان کنید. برچسب نمونه روی صفحه عمومی می‌ماند."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				variant: "quiet",
				onClick: async () => {
					const res = await createDemoFn();
					if (!res.ok) {
						toast.error(res.error);
						return;
					}
					localStorage.setItem("nobatak.business", res.data.businessId);
					window.location.assign("/panel");
				},
				children: "ساخت نمونه"
			})
		] })]
	});
	if (loading || !dash) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" });
	const total = Object.values(dash.byStatus).reduce((sum, n) => sum + n, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-4",
			children: [
				["امروز", dash.today],
				["بازه ۷ روز", total],
				["انجام‌شده", dash.byStatus.completed ?? 0],
				["لغوشده", dash.byStatus.cancelled ?? 0]
			].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-3xl font-extrabold tabular-nums",
				children: faNum(Number(value))
			})] }, String(label)))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-bold",
				children: "ظرفیت هفت روز آینده"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-6 text-muted",
				children: dash.capacity.formula
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-2 text-sm sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						"قابل عرضه: ",
						faNum(dash.capacity.availableMinutes),
						" دقیقه"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						"اشغال‌شده: ",
						faNum(dash.capacity.occupiedMinutes),
						" دقیقه"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						"آزاد: ",
						faNum(dash.capacity.freeMinutes),
						" دقیقه"
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-3 overflow-hidden rounded-full bg-paper-deep",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-jade",
					style: { width: `${dash.capacity.availableMinutes ? Math.min(100, dash.capacity.occupiedMinutes / dash.capacity.availableMinutes * 100) : 0}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/panel/calendar",
				className: "mt-4 inline-flex text-sm font-semibold text-jade",
				children: "تقویم نوبت‌ها"
			})
		] })]
	});
}
//#endregion
export { PanelHome as component };
