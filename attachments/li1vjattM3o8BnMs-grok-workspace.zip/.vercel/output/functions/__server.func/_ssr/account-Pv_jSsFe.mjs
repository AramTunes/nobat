import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as meFn } from "./fns-CBlOdITi.mjs";
import { n as useCurrentUserState } from "./use-current-user-B7Cbrtsy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-Pv_jSsFe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
require_jsx_runtime();
function useAccount() {
	const { user, isPending } = useCurrentUserState();
	const [me, setMe] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [nonce, setNonce] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (isPending) return;
		if (!user) {
			setLoading(false);
			return;
		}
		let live = true;
		meFn().then((res) => {
			if (!live) return;
			if (res.ok) setMe(res.data);
			else setError(res.error);
			setLoading(false);
		});
		return () => {
			live = false;
		};
	}, [
		user?.id,
		isPending,
		nonce
	]);
	return {
		user,
		isPending,
		me,
		error,
		loading,
		reload: () => {
			setLoading(true);
			setNonce((n) => n + 1);
		}
	};
}
function useBusinessId(memberships) {
	const [businessId, setBusinessId] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!memberships?.length) {
			setBusinessId("");
			return;
		}
		const saved = typeof window !== "undefined" ? localStorage.getItem("nobatak.business") ?? "" : "";
		const next = memberships.some((item) => item.businessId === saved) ? saved : memberships[0].businessId;
		setBusinessId(next);
	}, [memberships]);
	function choose(next) {
		localStorage.setItem("nobatak.business", next);
		setBusinessId(next);
	}
	return {
		businessId,
		choose
	};
}
var PanelState = (0, import_react.createContext)({
	businessId: "",
	memberships: []
});
function usePanel() {
	return (0, import_react.useContext)(PanelState);
}
//#endregion
export { usePanel as i, useAccount as n, useBusinessId as r, PanelState as t };
