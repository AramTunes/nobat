//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-OqnlF40J.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/panel",
			"/explore",
			"/login",
			"/me",
			"/api/health",
			"/api/auth/$",
			"/api/v1/$",
			"/b/$slug/book",
			"/b/$slug/"
		],
		preloads: [
			"/assets/index-DjfcnjHa.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/createClientRpc-CU7-gc4a.js",
			"/assets/preload-helper-BPg_V_ok.js",
			"/assets/link-2gxBe0a8.js",
			"/assets/matchContext-B4A6rP5h.js",
			"/assets/lazyRouteComponent-BVH7S0Ps.js",
			"/assets/useNavigate-BG-esEwo.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DjfcnjHa.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BvauG-gX.js",
			"/assets/fns-B7JnXfhz.js",
			"/assets/shell-Y6x8UAJn.js",
			"/assets/ui-D7zDyNn2.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin/route.tsx",
		children: [
			"/admin/audit",
			"/admin/businesses",
			"/admin/categories",
			"/admin/users",
			"/admin/"
		],
		preloads: [
			"/assets/route-DwmXmav0.js",
			"/assets/fns-B7JnXfhz.js",
			"/assets/shell-Y6x8UAJn.js",
			"/assets/ui-D7zDyNn2.js",
			"/assets/account-CjWE5ZO_.js"
		]
	},
	"/panel": {
		filePath: "/workspace/src/routes/panel/route.tsx",
		children: [
			"/panel/calendar",
			"/panel/customers",
			"/panel/services",
			"/panel/settings",
			"/panel/staff",
			"/panel/"
		],
		preloads: [
			"/assets/route-BLSY0hdU.js",
			"/assets/shell-Y6x8UAJn.js",
			"/assets/ui-D7zDyNn2.js",
			"/assets/fa-Cu-NxL8V.js",
			"/assets/account-CjWE5ZO_.js"
		]
	},
	"/explore": {
		filePath: "/workspace/src/routes/explore.tsx",
		children: void 0,
		preloads: [
			"/assets/explore-DZnwGQ7m.js",
			"/assets/fns-B7JnXfhz.js",
			"/assets/shell-Y6x8UAJn.js",
			"/assets/ui-D7zDyNn2.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-YlzWcCI0.js",
			"/assets/shell-Y6x8UAJn.js",
			"/assets/client-cLw6edTc.js",
			"/assets/ui-D7zDyNn2.js"
		]
	},
	"/me": {
		filePath: "/workspace/src/routes/me.tsx",
		children: void 0,
		preloads: [
			"/assets/me-DJdFi1gj.js",
			"/assets/fns-B7JnXfhz.js",
			"/assets/shell-Y6x8UAJn.js",
			"/assets/ui-D7zDyNn2.js",
			"/assets/fa-Cu-NxL8V.js",
			"/assets/format-DorEISlV.js",
			"/assets/account-CjWE5ZO_.js"
		]
	},
	"/admin/audit": {
		filePath: "/workspace/src/routes/admin/audit.tsx",
		children: void 0,
		preloads: [
			"/assets/audit-BSRtak6C.js",
			"/assets/fa-Cu-NxL8V.js",
			"/assets/format-DorEISlV.js"
		]
	},
	"/admin/businesses": {
		filePath: "/workspace/src/routes/admin/businesses.tsx",
		children: void 0,
		preloads: ["/assets/businesses-Ck4R8c5Q.js"]
	},
	"/admin/categories": {
		filePath: "/workspace/src/routes/admin/categories.tsx",
		children: void 0,
		preloads: ["/assets/categories-BnZpAT2R.js"]
	},
	"/admin/users": {
		filePath: "/workspace/src/routes/admin/users.tsx",
		children: void 0,
		preloads: ["/assets/users-B0jRKao2.js", "/assets/format-DorEISlV.js"]
	},
	"/panel/calendar": {
		filePath: "/workspace/src/routes/panel/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-BAHw_Gcb.js",
			"/assets/fns-B7JnXfhz.js",
			"/assets/jalali-calendar-A4EU6BKb.js",
			"/assets/format-DorEISlV.js"
		]
	},
	"/panel/customers": {
		filePath: "/workspace/src/routes/panel/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-ZGntK5cR.js",
			"/assets/fns-B7JnXfhz.js",
			"/assets/format-DorEISlV.js"
		]
	},
	"/panel/services": {
		filePath: "/workspace/src/routes/panel/services.tsx",
		children: void 0,
		preloads: ["/assets/services-B8DlbCyw.js", "/assets/fns-B7JnXfhz.js"]
	},
	"/panel/settings": {
		filePath: "/workspace/src/routes/panel/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-8Z0tMarw.js",
			"/assets/fns-B7JnXfhz.js",
			"/assets/jalali-calendar-A4EU6BKb.js",
			"/assets/format-DorEISlV.js"
		]
	},
	"/panel/staff": {
		filePath: "/workspace/src/routes/panel/staff.tsx",
		children: void 0,
		preloads: ["/assets/staff-BWNa9Tag.js", "/assets/fns-B7JnXfhz.js"]
	},
	"/admin/": {
		filePath: "/workspace/src/routes/admin/index.tsx",
		children: void 0,
		preloads: ["/assets/admin-C20LKHnz.js", "/assets/fa-Cu-NxL8V.js"]
	},
	"/panel/": {
		filePath: "/workspace/src/routes/panel/index.tsx",
		children: void 0,
		preloads: ["/assets/panel-CShyeOEB.js", "/assets/fns-B7JnXfhz.js"]
	},
	"/b/$slug/book": {
		filePath: "/workspace/src/routes/b/$slug/book.tsx",
		children: void 0,
		preloads: [
			"/assets/book-DmqVva2J.js",
			"/assets/fns-B7JnXfhz.js",
			"/assets/shell-Y6x8UAJn.js",
			"/assets/jalali-calendar-A4EU6BKb.js",
			"/assets/ui-D7zDyNn2.js",
			"/assets/fa-Cu-NxL8V.js",
			"/assets/format-DorEISlV.js",
			"/assets/use-current-user-DQB55Vmc.js"
		]
	},
	"/b/$slug/": {
		filePath: "/workspace/src/routes/b/$slug/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-WX0un7cw.js",
			"/assets/fns-B7JnXfhz.js",
			"/assets/shell-Y6x8UAJn.js",
			"/assets/ui-D7zDyNn2.js",
			"/assets/fa-Cu-NxL8V.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
