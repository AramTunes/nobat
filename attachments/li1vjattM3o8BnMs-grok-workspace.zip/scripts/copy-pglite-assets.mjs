import { copyFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const from = join(root, "node_modules/@electric-sql/pglite/dist");
const dest = join(root, ".vercel/output/functions/__server.func/_libs");
const files = ["pglite.data", "pglite.wasm", "initdb.wasm"];

if (!existsSync(dest)) {
  console.log("[pglite] no server bundle yet, skip asset copy");
  process.exit(0);
}
for (const name of files) {
  copyFileSync(join(from, name), join(dest, name));
}
console.log("[pglite] copied data and wasm next to the server bundle");
